const fs = require('node:fs/promises');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { build, Platform } = require('electron-builder');

const root = path.resolve(__dirname, '..');
const staging = path.join(root, '.desktop-stage');

function installRuntime() {
  return new Promise((resolve, reject) => {
    const windows = process.platform === 'win32';
    const child = spawn(windows ? (process.env.ComSpec || 'cmd.exe') : 'npm', windows
      ? ['/d', '/s', '/c', 'npm install --omit=dev --ignore-scripts --no-fund']
      : ['install', '--omit=dev', '--ignore-scripts', '--no-fund'], { cwd: staging, stdio: 'inherit' });
    child.once('error', reject);
    child.once('exit', code => code === 0 ? resolve() : reject(new Error(`Installation des dependances impossible (code ${code}).`)));
  });
}

async function packageDesktop() {
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major < 22 || (major === 22 && minor < 12)) throw new Error('Utilise Node.js 22.12+ pour packager Electron.');
  await fs.access(path.join(root, 'dist', 'index.html')).catch(() => { throw new Error('Execute npm run build avant de preparer le package.'); });
  await fs.rm(staging, { recursive: true, force: true });
  await fs.mkdir(staging, { recursive: true });
  await fs.cp(path.join(root, 'dist'), path.join(staging, 'dist'), { recursive: true });
  await fs.cp(path.join(root, 'electron'), path.join(staging, 'electron'), { recursive: true });
  // This generated application manifest is separate from the Vite project manifest.
  const manifest = {
    name: 'dofus-craft', version: '0.2.0', private: true, main: 'electron/main.cjs',
    description: 'Launcher Minecraft Dofus Craft', author: 'Dofus Craft', license: 'UNLICENSED',
    dependencies: { 'minecraft-launcher-core': '3.18.2', msmc: '5.0.5', 'extract-zip': '2.0.1', tar: '7.5.22' },
  };
  await fs.writeFile(path.join(staging, 'package.json'), JSON.stringify(manifest, null, 2));
  await installRuntime();
  const platform = process.argv.includes('--win') ? Platform.WINDOWS : process.argv.includes('--mac') ? Platform.MAC : process.argv.includes('--linux') ? Platform.LINUX : Platform.current();
  const customIcon = path.join(root, 'public', 'images', 'app-icon.png');
  const icon = await fs.access(customIcon).then(() => customIcon).catch(() => path.join(root, 'public', 'images', 'emerald-item.png'));
  const artifacts = await build({
    projectDir: staging,
    targets: platform.createTarget(),
    publish: 'never',
    config: {
      extends: null,
      appId: 'fr.dofuscraft.launcher', productName: 'Dofus Craft',
      electronVersion: require('electron/package.json').version,
      directories: { output: path.join(root, 'release') },
      files: ['dist/**/*', 'electron/**/*'],
      asar: false, npmRebuild: false,
      win: { icon, target: 'nsis' },
      mac: { icon, target: 'dmg', category: 'public.app-category.games' },
      linux: { icon, target: 'AppImage', category: 'Game' },
      nsis: { oneClick: false, allowToChangeInstallationDirectory: true, createDesktopShortcut: true, createStartMenuShortcut: true },
    },
  });
  console.log('Packages crees :\n' + artifacts.join('\n'));
}

packageDesktop().catch(error => { console.error(`\nDofus Craft : ${error.message}`); process.exitCode = 1; });