const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const vm = require('node:vm');
const { validateOptions, quickPlayOptions, redact } = require('../electron/launch-utils.cjs');

const input = { version: '1.21.4', ram: 4, serverHost: 'localhost', serverPort: 25565, autoJoin: true, javaPath: '' };

test('all Electron entrypoints have valid CommonJS syntax', () => {
  const directory = path.join(__dirname, '../electron');
  for (const file of fs.readdirSync(directory).filter(file => file.endsWith('.cjs'))) new vm.Script(fs.readFileSync(path.join(directory, file), 'utf8'), { filename: file });
});
test('validates the launch options without passing arbitrary options through', () => {
  const options = validateOptions({ ...input, authorization: 'injected', command: 'injected' });
  assert.equal(options.ram, 4);
  assert.equal(options.serverHost, 'localhost');
  assert.equal(options.authorization, undefined);
  assert.equal(options.command, undefined);
});
test('rejects unsupported versions, bad memory, ports and hosts', () => {
  for (const override of [{ version: '../../evil' }, { ram: 0 }, { ram: 24 }, { ram: 4.5 }, { serverPort: 0 }, { serverPort: 65536 }, { serverHost: 'https://server.test' }, { serverHost: 'host:1234' }, { serverHost: 'bad..test' }, { serverHost: 'hello;command' }]) {
    assert.throws(() => validateOptions({ ...input, ...override }));
  }
});
test('uses modern Quick Play, not the ignored server option', () => {
  const options = quickPlayOptions('1.21.4', 'localhost', 25565);
  assert.deepEqual(options, { quickPlay: { type: 'multiplayer', identifier: 'localhost:25565' } });
  assert.equal(options.server, undefined);
});
test('uses legacy flags for Minecraft 1.19', () => {
  assert.equal(quickPlayOptions('1.19.4', 'localhost', 25566).quickPlay.type, 'legacy');
});
test('does not invent an IP when no server is configured', () => {
  assert.deepEqual(quickPlayOptions('1.21.4', '', 25565), {});
  assert.equal(validateOptions({ ...input, autoJoin: false }).serverHost, '');
});
test('formats IPv6 safely on modern versions', () => {
  assert.equal(quickPlayOptions('1.21.4', '::1', 25565).quickPlay.identifier, '[::1]:25565');
  assert.throws(() => validateOptions({ ...input, version: '1.19.4', serverHost: '::1' }));
});
test('rejects relative executables and shell metacharacters', () => {
  assert.throws(() => validateOptions({ ...input, javaPath: 'java' }));
  assert.throws(() => validateOptions({ ...input, javaPath: path.resolve('injected" & command/java') }));
});
test('tokens are redacted from diagnostic output', () => {
  const log = redact('token super-secret-token --accessToken hidden-access-token Bearer hidden-bearer-token', ['super-secret-token']);
  assert.equal(log.includes('super-secret-token'), false);
  assert.equal(log.includes('hidden-access-token'), false);
  assert.equal(log.includes('hidden-bearer-token'), false);
});
test('MSMC export and MCLC version match the integration', () => {
  const { Auth, lexicon } = require('msmc');
  assert.equal(typeof Auth, 'function');
  assert.equal(typeof lexicon.wrapError, 'function');
  const { Client } = require('minecraft-launcher-core');
  assert.equal(typeof Client.prototype.startMinecraft, 'function');
  assert.equal(require('minecraft-launcher-core/package.json').version, '3.18.2');
});