const { Client } = require('minecraft-launcher-core');
const { spawn, execFile } = require('node:child_process');
const fs = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { fetchJson, hashFile, downloadFile, ensureJava } = require('./runtime.cjs');
const { quickPlayOptions, redact } = require('./launch-utils.cjs');

let game = null;
let secrets = [];
let lastUpdate = 0;
let lastStage = '';
let stopping = false;
let failed = false;
const send = (type, data) => process.parentPort.postMessage({ type, data });
const log = (text, level = 'info') => send('log', { text: redact(text, secrets).slice(0, 5000), level });
const update = data => {
  if (data.progress !== null && data.progress !== 100 && data.stage === lastStage && Date.now() - lastUpdate < 150) return;
  lastStage = data.stage;
  lastUpdate = Date.now();
  send('state', data);
};
function fail(error) {
  if (failed || stopping) return;
  failed = true;
  const message = redact(error?.message || String(error), secrets);
  log(message, 'error');
  send('failure', message);
  setTimeout(() => process.exit(1), 150);
}
process.on('uncaughtException', fail);
process.on('unhandledRejection', fail);

function queueDownloads(limit) {
  let active = 0;
  const queue = [];
  const pump = () => {
    while (active < limit && queue.length) {
      const { work, resolve, reject } = queue.shift();
      active++;
      Promise.resolve().then(work).then(resolve, reject).finally(() => { active--; pump(); });
    }
  };
  return work => new Promise((resolve, reject) => { queue.push({ work, resolve, reject }); pump(); });
}

async function run({ options, authorization, rootDir, runtimeDir }) {
  secrets = [authorization.access_token, authorization.client_token];
  const version = options.version;
  await fs.mkdir(rootDir, { recursive: true });
  update({ phase: 'preparing', stage: 'verification', progress: null, title: 'Verification de Minecraft', detail: `Lecture du manifeste officiel ${version}` });
  const manifest = await fetchJson('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
  const entry = manifest.versions.find(item => item.id === version && item.type === 'release');
  if (!entry) throw new Error(`Version officielle introuvable : ${version}`);
  const response = await fetch(entry.url, { signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error(`Manifeste Minecraft indisponible : HTTP ${response.status}`);
  const raw = await response.text();
  if (entry.sha1 && createHash('sha1').update(raw).digest('hex') !== entry.sha1) throw new Error('Le manifeste Minecraft est corrompu. Reessaie.');
  const metadata = JSON.parse(raw);
  const versionDir = path.join(rootDir, 'versions', version);
  await fs.mkdir(versionDir, { recursive: true });
  const versionJson = path.join(versionDir, `${version}.json`);
  await fs.writeFile(versionJson, raw);
  const javaPath = await ensureJava({ major: metadata.javaVersion?.majorVersion || 17, customPath: options.javaPath, directory: runtimeDir, update, log });

  update({ phase: 'preparing', stage: 'minecraft', progress: null, title: 'Verification des fichiers', detail: 'Les fichiers deja installes sont reutilises.', current: 0, total: 0, speed: 0 });
  const jar = path.join(versionDir, `${version}.jar`);
  const artifacts = [{ file: jar, sha1: metadata.downloads.client.sha1 }];
  for (const library of metadata.libraries || []) {
    const downloads = [library.downloads?.artifact, ...Object.values(library.downloads?.classifiers || {})].filter(Boolean);
    for (const artifact of downloads) if (artifact.path && artifact.sha1) artifacts.push({ file: path.join(rootDir, 'libraries', artifact.path), sha1: artifact.sha1 });
  }
  for (const artifact of artifacts) {
    const exists = await fs.stat(artifact.file).catch(() => null);
    if (exists && await hashFile(artifact.file, 'sha1') !== artifact.sha1) {
      log(`Reparation du fichier : ${path.basename(artifact.file)}`, 'warn');
      await fs.rm(artifact.file, { force: true });
    }
  }

  const client = new Client();
  let lastError = '';
  client.on('debug', text => {
    // Launch arguments contain the Microsoft token and are never sent to the UI or disk.
    if (/Launching with arguments/i.test(text)) return;
    if (/failed|couldn't|error|ENOTFOUND|ECONN/i.test(text)) lastError = redact(text, secrets);
    log(text, /failed|error/i.test(text) ? 'warn' : 'info');
  });
  const labels = { assets: 'Ressources du jeu', classes: 'Bibliotheques', natives: 'Composants natifs', 'version-jar': 'Minecraft', 'asset-json': 'Index des ressources' };
  let fileProgress = null;
  client.on('progress', event => {
    fileProgress = event;
    const total = Number(event.total) || 0;
    const current = Math.min(Number(event.task) || 0, total);
    update({ phase: 'downloading', stage: 'minecraft', title: labels[event.type] || 'Installation de Minecraft', detail: total ? `${current} / ${total} fichiers verifies` : 'Preparation des fichiers', progress: total ? Math.round(current / total * 100) : null, current, total, unit: 'files', speed: 0 });
  });
  client.on('download-status', event => {
    const summary = fileProgress;
    update({ phase: 'downloading', stage: 'minecraft', title: labels[event.type] || 'Telechargement de Minecraft', detail: event.name,
      progress: summary?.total ? Math.round(Math.min(summary.task / summary.total, 1) * 100) : event.total ? Math.round(event.current / event.total * 100) : null,
      current: event.current, total: event.total, unit: 'bytes', speed: event.speed || 0 });
  });
  client.on('arguments', () => update({ phase: 'launching', stage: 'launch', progress: null, title: 'Ouverture de Minecraft', detail: 'Demarrage du processus Java. Patiente quelques instants.', speed: 0 }));

  // Attach process listeners before Node can emit a spawn error.
  client.startMinecraft = args => {
    game = spawn(javaPath, args, { cwd: rootDir, detached: false, windowsHide: true });
    game.once('error', fail);
    game.once('spawn', () => {
      if (stopping) { game.kill(); return; }
      log(`Processus Minecraft demarre (PID ${game.pid}).`);
      send('started', { pid: game.pid, detail: options.serverHost ? `Connexion demandee a ${options.serverHost}:${options.serverPort}` : 'Minecraft est ouvert. Aucun serveur configure.' });
    });
    game.stdout.on('data', chunk => log(String(chunk)));
    game.stderr.on('data', chunk => log(String(chunk), 'warn'));
    game.once('close', (code, signal) => {
      send('closed', { code, signal, stopped: stopping });
      game = null;
      setTimeout(() => process.exit(0), 150);
    });
    return game;
  };

  log(options.serverHost ? `Connexion directe : ${options.serverHost}:${options.serverPort}` : 'Aucune IP configuree : ouverture du menu principal.', options.serverHost ? 'info' : 'warn');
  const pending = client.launch({
    authorization, root: rootDir, javaPath,
    version: { number: version, type: 'release' },
    memory: { max: `${options.ram}G`, min: '1G' },
    window: options.fullscreen ? { fullscreen: true } : { width: 1280, height: 720 },
    timeout: 60000,
    ...quickPlayOptions(version, options.serverHost, options.serverPort),
    overrides: { detached: false, versionJson, maxSockets: 6 },
  });

  // MCLC 3.18.2 initializes its handler before its first await. Atomic downloads
  // prevent an interrupted installation from leaving truncated JARs in the cache.
  if (!client.handler) throw new Error('Version du moteur MCLC incompatible. Version attendue : 3.18.2.');
  const enqueue = queueDownloads(6);
  const downloads = new Map();
  client.handler.downloadAsync = (url, directory, name, retry, type) => {
    const destination = path.resolve(directory, name);
    // Several asset names can point at the same hash; never write their .part file twice.
    if (!downloads.has(destination)) downloads.set(destination, enqueue(async () => {
      await downloadFile(url, destination, data => client.emit('download-status', { ...data, name, type }));
      client.emit('download', name);
      return { failed: false, asset: null };
    }));
    return downloads.get(destination);
  };
  const processHandle = await pending;
  if (!processHandle && !stopping) throw new Error(lastError || 'Minecraft n\'a pas pu demarrer. Consulte le journal pour connaitre la cause.');
}

process.parentPort.on('message', ({ data }) => {
  if (data.type === 'launch') run(data).catch(fail);
  if (data.type === 'stop') {
    stopping = true;
    if (!game?.pid) process.exit(0);
    else if (process.platform === 'win32') execFile('taskkill', ['/pid', String(game.pid), '/T', '/F'], { windowsHide: true }, () => {});
    else game.kill('SIGTERM');
  }
});