const path = require('node:path');
const net = require('node:net');

const VERSIONS = ['1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.19.4'];

function validateOptions(input = {}) {
  if (!VERSIONS.includes(input.version)) throw new Error('Version Minecraft non prise en charge.');
  const ram = Number(input.ram);
  if (!Number.isInteger(ram) || ram < 2 || ram > 16) throw new Error('La memoire doit etre comprise entre 2 et 16 Go.');
  const host = input.autoJoin === false ? '' : String(input.serverHost || '').trim();
  const port = Number(input.serverPort ?? 25565);
  const validDomain = host.length <= 253 && host.split('.').every(label => /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/.test(label));
  if (host && !net.isIP(host) && !validDomain) {
    throw new Error("Adresse serveur invalide. Indique un domaine ou une IP, sans https:// ni port.");
  }
  if (net.isIP(host) === 6 && Number(input.version.split('.')[1]) < 20) throw new Error('La connexion IPv6 directe requiert Minecraft 1.20 ou plus recent. Utilise un domaine pour cette version.');
  if (/tonserveur|example\./i.test(host)) throw new Error("Remplace l'adresse d'exemple par celle de ton serveur dans les parametres.");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Port serveur invalide.');
  const javaPath = String(input.javaPath || '').trim().replace(/javaw\.exe$/i, 'java.exe');
  // MCLC checks Java through a shell. Reject shell metacharacters even though our own checks use execFile.
  if (javaPath && (!path.isAbsolute(javaPath) || /["`$%&|<>^!\r\n]/.test(javaPath) || !/^java(?:w)?(?:\.exe)?$/i.test(path.basename(javaPath)))) {
    throw new Error('Selectionne un executable java.exe ou java valide avec le bouton Parcourir.');
  }
  return {
    version: input.version, ram, javaPath,
    fullscreen: input.fullscreen === true,
    hideOnLaunch: input.hideOnLaunch === true,
    serverHost: input.autoJoin === false ? '' : host,
    serverPort: port,
  };
}

function quickPlayOptions(version, host, port) {
  if (!host) return {};
  const address = net.isIP(host) === 6 ? `[${host}]` : host;
  return { quickPlay: { type: Number(version.split('.')[1]) >= 20 ? 'multiplayer' : 'legacy', identifier: `${address}:${port}` } };
}

function redact(value, secrets = []) {
  let text = String(value ?? '');
  for (const secret of secrets) if (secret && secret.length > 5) text = text.split(secret).join('[REDACTED]');
  return text
    .replace(/(--(?:accessToken|clientId|xuid)\s+)[^\s]+/gi, '$1[REDACTED]')
    .replace(/(Bearer\s+)[^\s]+/gi, '$1[REDACTED]')
    .replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, '[REDACTED]');
}

module.exports = { VERSIONS, validateOptions, quickPlayOptions, redact };