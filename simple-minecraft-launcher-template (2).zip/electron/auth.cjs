const { Auth, lexicon } = require('msmc');
const { safeStorage } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');

class MicrosoftAccount {
  constructor(directory) {
    this.file = path.join(directory, 'microsoft-session.bin');
    this.auth = new Auth('select_account');
    this.minecraft = null;
    this.refreshToken = null;
    this.profile = null;
    this.pending = null;
    this.revision = 0;
  }

  async restore() {
    try {
      if (!safeStorage.isEncryptionAvailable() || safeStorage.getSelectedStorageBackend?.() === 'basic_text') return;
      const saved = JSON.parse(safeStorage.decryptString(await fs.readFile(this.file)));
      if (typeof saved.refreshToken === 'string' && saved.profile?.uuid && saved.profile?.name) {
        this.refreshToken = saved.refreshToken;
        this.profile = saved.profile;
      }
    } catch { this.profile = null; }
  }

  async accept(xbox, revision = this.revision) {
    const minecraft = await xbox.getMinecraft();
    if (revision !== this.revision) throw new Error('Connexion annulee.');
    if (!minecraft.profile?.id || minecraft.isDemo()) throw new Error('Ce compte ne possede pas Minecraft Java Edition. Connecte le compte qui possede le jeu.');
    this.minecraft = minecraft;
    this.refreshToken = xbox.save();
    this.profile = { name: minecraft.profile.name, uuid: minecraft.profile.id };
    if (safeStorage.isEncryptionAvailable() && safeStorage.getSelectedStorageBackend?.() !== 'basic_text') {
      await fs.mkdir(path.dirname(this.file), { recursive: true });
      await fs.writeFile(this.file, safeStorage.encryptString(JSON.stringify({ profile: this.profile, refreshToken: this.refreshToken })), { mode: 0o600 });
    }
    return this.profile;
  }

  async login(parent) {
    if (this.pending) return this.pending;
    const revision = ++this.revision;
    this.pending = (async () => {
      let timer;
      let rejectTimeout;
      const timeout = new Promise((_resolve, reject) => { rejectTimeout = reject; });
      const startTimer = () => {
        timer = setTimeout(() => {
          if (this.revision === revision) this.revision++;
          rejectTimeout(new Error('La connexion Microsoft a pris trop de temps. Verifie ta connexion puis reessaie.'));
        }, 90000);
      };
      // Let the player complete the login form; only time out the subsequent API requests.
      this.auth.once('load', startTimer);
      try {
        const xbox = await Promise.race([this.auth.launch('electron', {
          width: 520, height: 720, parent, modal: true, autoHideMenuBar: true,
          title: 'Dofus Craft - Connexion Microsoft',
          webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, partition: 'persist:dofus-microsoft' },
        }), timeout]);
        return await Promise.race([this.accept(xbox, revision), timeout]);
      } catch (error) {
        const wrapped = lexicon.wrapError(error);
        throw new Error(error instanceof Error ? error.message : wrapped?.message || 'Connexion Microsoft annulee ou impossible.');
      } finally { clearTimeout(timer); this.auth.removeListener('load', startTimer); this.pending = null; }
    })();
    return this.pending;
  }

  async authorization() {
    if (this.minecraft?.validate()) return this.minecraft.mclc();
    if (!this.refreshToken) throw new Error('Connecte ton compte Microsoft avant de jouer.');
    const revision = this.revision;
    try {
      await this.accept(await this.auth.refresh(this.refreshToken), revision);
      return this.minecraft.mclc();
    } catch { throw new Error('Ta session Microsoft a expire ou le service est indisponible. Reconnecte-toi depuis ton profil.'); }
  }

  async logout() {
    this.revision++;
    this.minecraft = null;
    this.refreshToken = null;
    this.profile = null;
    await fs.rm(this.file, { force: true });
  }
}

module.exports = { MicrosoftAccount };