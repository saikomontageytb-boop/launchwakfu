const { contextBridge, ipcRenderer } = require('electron');

// Only payloads cross the bridge; IPC events and tokens stay out of the renderer.
function subscribe(channel, callback) {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld('electronAPI', {
  version: 2,
  getSession: () => ipcRenderer.invoke('account:session'),
  login: () => ipcRenderer.invoke('account:login'),
  logout: () => ipcRenderer.invoke('account:logout'),
  getLaunchState: () => ipcRenderer.invoke('launcher:snapshot'),
  launchMinecraft: options => ipcRenderer.invoke('launcher:launch', options),
  stopMinecraft: () => ipcRenderer.invoke('launcher:stop'),
  chooseJava: () => ipcRenderer.invoke('launcher:java'),
  openFolder: kind => ipcRenderer.invoke('launcher:folder', kind),
  exportLogs: () => ipcRenderer.invoke('launcher:export'),
  windowControl: action => ipcRenderer.invoke('window:control', action),
  onState: callback => subscribe('launcher:state', callback),
  onLog: callback => subscribe('launcher:log', callback),
});