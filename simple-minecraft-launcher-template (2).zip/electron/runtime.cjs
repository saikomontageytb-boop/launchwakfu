const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { Readable, Transform } = require('node:stream');
const { pipeline } = require('node:stream/promises');
const extract = require('extract-zip');
const tar = require('tar');
const exec = promisify(execFile);

async function fetchJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(45000) });
  if (!res.ok) throw new Error(`Service indisponible (HTTP ${res.status}) : ${new URL(url).hostname}`);
  return res.json();
}

async function hashFile(file, algorithm = 'sha256') {
  const hash = createHash(algorithm);
  for await (const chunk of fs.createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}

async function downloadFile(url, destination, onProgress = () => {}, checksum) {
  if (new URL(url).protocol !== 'https:') throw new Error('Telechargement non securise refuse.');
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  const part = `${destination}.part`;
  for (let attempt = 0; attempt < 3; attempt++) {
    const controller = new AbortController();
    let timer = setTimeout(() => controller.abort(), 60000);
    try {
      const response = await fetch(url, { signal: controller.signal, headers: { 'Accept-Encoding': 'identity' } });
      if (!response.ok || !response.body) throw new Error(`HTTP ${response.status} pour ${path.basename(destination)}`);
      if (new URL(response.url).protocol !== 'https:') throw new Error('Redirection non securisee refusee.');
      const encoding = response.headers.get('content-encoding');
      const total = encoding && encoding !== 'identity' ? 0 : Number(response.headers.get('content-length')) || 0;
      let current = 0;
      const started = Date.now();
      const progress = new Transform({
        transform(chunk, encoding, callback) {
          current += chunk.length;
          clearTimeout(timer);
          timer = setTimeout(() => controller.abort(), 60000);
          onProgress({ current, total, speed: current / Math.max(1, (Date.now() - started) / 1000) });
          callback(null, chunk);
        },
      });
      await pipeline(Readable.fromWeb(response.body), progress, fs.createWriteStream(part), { signal: controller.signal });
      if (total && current !== total) throw new Error('Telechargement incomplet.');
      if (checksum && await hashFile(part) !== checksum.toLowerCase()) throw new Error('La verification SHA-256 de Java a echoue.');
      await fsp.rm(destination, { force: true });
      await fsp.rename(part, destination);
      return;
    } catch (error) {
      await fsp.rm(part, { force: true }).catch(() => {});
      if (attempt === 2) throw error;
      await new Promise(resolve => setTimeout(resolve, 800 * (attempt + 1)));
    } finally {
      clearTimeout(timer);
    }
  }
}

async function inspectJava(executable) {
  try {
    const { stdout, stderr } = await exec(executable, ['-XshowSettings:properties', '-version'], { timeout: 12000, windowsHide: true });
    const output = `${stdout}\n${stderr}`;
    const version = output.match(/(?:java\.version\s*=\s*|version\s+")(\d+)(?:\.(\d+))?/);
    const major = version ? Number(version[1] === '1' ? version[2] : version[1]) : 0;
    const is64Bit = /(?:sun\.arch\.data\.model\s*=\s*64|64-Bit|aarch64|amd64|x86_64)/i.test(output);
    return { executable, major, is64Bit };
  } catch {
    return null;
  }
}

async function findJava(directory, depth = 0) {
  if (depth > 5) return null;
  const entries = await fsp.readdir(directory, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    if (entry.isFile() && entry.name === (process.platform === 'win32' ? 'java.exe' : 'java') && path.basename(directory) === 'bin') {
      return path.join(directory, entry.name);
    }
  }
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const found = await findJava(path.join(directory, entry.name), depth + 1);
    if (found) return found;
  }
  return null;
}

async function ensureJava({ major, customPath, directory, update, log }) {
  update({ stage: 'java', phase: 'preparing', progress: null, title: `Verification de Java ${major}`, detail: 'Recherche d\'un environnement 64 bits compatible.' });
  if (customPath) {
    const java = await inspectJava(customPath);
    if (!java || java.major !== major || !java.is64Bit) throw new Error(`Java ${major} 64 bits est requis. Vide le chemin Java pour activer l'installation automatique.`);
    log(`Java personnalise : ${java.executable}`);
    return java.executable;
  }
  const target = path.join(directory, `temurin-${major}-${process.platform}-${process.arch}`);
  const installed = await findJava(target);
  const candidates = [installed, process.env.JAVA_HOME && path.join(process.env.JAVA_HOME, 'bin', process.platform === 'win32' ? 'java.exe' : 'java'), 'java'].filter(Boolean);
  for (const executable of candidates) {
    const java = await inspectJava(executable);
    if (java && java.major === major && java.is64Bit) {
      log(`Java ${major} 64 bits disponible : ${executable}`);
      return executable;
    }
  }
  const os = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = { x64: 'x64', arm64: 'aarch64' }[process.arch];
  if (!os || !arch) throw new Error('Installation automatique disponible sur Windows, macOS et Linux 64 bits.');
  log(`Installation de Temurin Java ${major} depuis Adoptium.`);
  const releases = await fetchJson(`https://api.adoptium.net/v3/assets/latest/${major}/hotspot?architecture=${arch}&image_type=jre&os=${os}&vendor=eclipse`);
  const pkg = releases[0]?.binary?.package;
  if (!pkg?.link || !pkg.checksum || !/^[a-f0-9]{64}$/i.test(pkg.checksum)) throw new Error('Aucun environnement Java compatible trouve chez Adoptium.');
  const archive = path.join(directory, `java-${major}-${process.arch}.${os === 'windows' ? 'zip' : 'tar.gz'}`);
  await downloadFile(pkg.link, archive, ({ current, total, speed }) => {
    update({ stage: 'java', phase: 'downloading', title: `Installation de Java ${major}`, detail: 'Telechargement securise depuis Adoptium', progress: total ? Math.round(current / total * 100) : null, current, total, speed, unit: 'bytes' });
  }, pkg.checksum);
  update({ stage: 'java', phase: 'preparing', title: 'Extraction de Java', detail: 'Archive verifiee (SHA-256). Installation locale.', progress: null, speed: 0 });
  const staging = `${target}.installing`;
  await fsp.rm(staging, { recursive: true, force: true });
  await fsp.mkdir(staging, { recursive: true });
  if (os === 'windows') await extract(archive, { dir: path.resolve(staging) });
  else await tar.x({ file: archive, cwd: staging, strict: true, preservePaths: false });
  const binary = await findJava(staging);
  if (!binary) throw new Error("L'archive Java ne contient pas d'executable.");
  if (process.platform !== 'win32') await fsp.chmod(binary, 0o755);
  const verified = await inspectJava(binary);
  if (!verified || verified.major !== major || !verified.is64Bit) throw new Error('La verification du Java installe a echoue.');
  const relative = path.relative(staging, binary);
  await fsp.rm(target, { recursive: true, force: true });
  await fsp.rename(staging, target);
  await fsp.rm(archive, { force: true });
  log(`Java ${major} installe et verifie.`);
  return path.join(target, relative);
}

module.exports = { fetchJson, hashFile, downloadFile, ensureJava, inspectJava };