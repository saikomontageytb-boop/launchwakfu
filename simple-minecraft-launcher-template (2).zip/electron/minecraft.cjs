const { utilityProcess } = require('electron');
const { execFile } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { validateOptions, redact } = require('./launch-utils.cjs');

class MinecraftLauncher {
  constructor({ directory, account, notify, onStarted, onClosed }) {
    this.account = account;
    this.notify = notify;
    this.onStarted = onStarted;
    this.onClosed = onClosed;
    this.rootDir = path.join(directory, 'minecraft');
    this.runtimeDir = path.join(directory, 'runtime');
    this.logDir = path.join(directory, 'logs');
    fs.mkdirSync(this.logDir, { recursive: true });
    this.logFile = path.join(this.logDir, 'launcher.log');
    this.logs = [];
    this.worker = null;
    this.generation = 0;
    this.secrets = [];
    this.logBytes = 0;
    this.state = { phase: 'idle', stage: 'verification', progress: null, title: 'Pret a jouer', detail: '', error: null, pid: null, startedAt: null, updatedAt: Date.now(), current: 0, total: 0, speed: 0, unit: 'files' };
  }

  get busy() { return !['idle', 'error'].includes(this.state.phase); }
  snapshot() { return { state: this.state, logs: this.logs }; }
  setState(patch) {
    this.state = { ...this.state, ...patch, updatedAt: Date.now() };
    this.notify('launcher:state', this.state);
  }
  log(text, level = 'info') {
    const entry = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, time: new Date().toISOString(), text: redact(text, this.secrets).slice(0, 5000), level };
    this.logs = [...this.logs.slice(-399), entry];
    this.notify('launcher:log', entry);
    if (this.logBytes < 5 * 1024 * 1024) {
      const line = `${entry.time} [${level}] ${entry.text}\n`;
      this.logBytes += Buffer.byteLength(line);
      fs.appendFile(this.logFile, line, () => {});
    }
  }

  launch(input) {
    if (this.busy) throw new Error('Un lancement est deja en cours.');
    const options = validateOptions(input);
    const totalGiB = Math.floor(os.totalmem() / 1024 ** 3);
    if (options.ram > totalGiB - 1) throw new Error(`Ton ordinateur dispose de ${totalGiB} Go. Reduis la RAM allouee dans les parametres.`);
    if (!this.account.profile) throw new Error('Connecte ton compte Microsoft avant de jouer.');
    const generation = ++this.generation;
    this.logs = [];
    this.logBytes = 0;
    fs.writeFileSync(this.logFile, 'Dofus Craft - Journal de lancement\n');
    this.setState({ phase: 'authenticating', stage: 'verification', progress: null, error: null, title: 'Verification du compte', detail: 'Verification de la session Microsoft.', startedAt: Date.now(), pid: null, current: 0, total: 0, speed: 0 });
    this.log(`Minecraft ${options.version}, ${options.ram} Go, ${process.platform} ${process.arch}`);
    this.prepare(options, generation).catch(error => { if (generation === this.generation) this.fail(error.message || String(error)); });
    return { accepted: true };
  }

  async prepare(options, generation) {
    let timeout;
    const authorization = await Promise.race([
      this.account.authorization(),
      new Promise((_resolve, reject) => { timeout = setTimeout(() => reject(new Error('Microsoft ne repond pas. Verifie ta connexion puis reconnecte ton compte.')), 60000); }),
    ]).finally(() => clearTimeout(timeout));
    if (generation !== this.generation) return;
    this.secrets = [authorization.access_token, authorization.client_token];
    this.log('Session Microsoft verifiee.');
    this.setState({ phase: 'preparing', detail: 'Demarrage du moteur Minecraft.' });
    const worker = utilityProcess.fork(path.join(__dirname, 'launch-worker.cjs'), [], { serviceName: 'Dofus Craft Minecraft', stdio: 'pipe' });
    this.worker = worker;
    this.lastActivity = Date.now();
    this.watchdog = setInterval(() => {
      if (!['running', 'stopping'].includes(this.state.phase) && Date.now() - this.lastActivity > 180000) this.fail('Aucune activite depuis 3 minutes. Verifie ta connexion et le pare-feu, puis reessaie.');
    }, 5000);
    worker.stdout?.on('data', chunk => { if (generation === this.generation) this.log(String(chunk)); });
    worker.stderr?.on('data', chunk => { if (generation === this.generation) this.log(String(chunk), 'warn'); });
    worker.on('message', message => {
      if (generation !== this.generation) return;
      this.lastActivity = Date.now();
      if (message.type === 'log') this.log(message.data.text, message.data.level);
      if (message.type === 'state' && this.state.phase !== 'stopping') this.setState(message.data);
      if (message.type === 'failure') this.fail(message.data);
      if (message.type === 'started') {
        this.setState({ phase: 'running', stage: 'ready', progress: 100, title: 'Minecraft est ouvert', detail: message.data.detail, pid: message.data.pid, speed: 0 });
        this.onStarted(options.hideOnLaunch);
      }
      if (message.type === 'closed') {
        clearInterval(this.watchdog);
        const { code, stopped } = message.data;
        if (code !== 0 && !stopped) this.fail(`Minecraft s'est ferme avec le code ${code ?? 'inconnu'}. Consulte les dernieres lignes du journal.`);
        else this.setState({ phase: 'idle', progress: null, pid: null, title: stopped ? 'Minecraft arrete' : 'A bientot dans Dofus Craft', detail: 'Le journal de cette session reste disponible.' });
        this.onClosed();
      }
    });
    worker.on('exit', code => {
      if (this.worker === worker) this.worker = null;
      if (generation !== this.generation) return;
      clearInterval(this.watchdog);
      if (!['idle', 'error', 'stopping'].includes(this.state.phase)) this.fail(`Le moteur de lancement s'est arrete (code ${code}). Consulte le journal.`);
    });
    worker.postMessage({ type: 'launch', options, authorization, rootDir: this.rootDir, runtimeDir: this.runtimeDir });
  }

  fail(message) {
    clearInterval(this.watchdog);
    const safe = redact(message, this.secrets);
    this.log(safe, 'error');
    ++this.generation;
    if (this.state.pid) {
      if (process.platform === 'win32') execFile('taskkill', ['/pid', String(this.state.pid), '/T', '/F'], { windowsHide: true }, () => {});
      else { try { process.kill(this.state.pid, 'SIGTERM'); } catch { /* Already closed. */ } }
    }
    this.worker?.kill();
    this.worker = null;
    this.setState({ phase: 'error', error: safe, title: 'Le lancement a rencontre un probleme', detail: safe, progress: null, speed: 0, pid: null });
    this.onClosed();
  }

  async stop() {
    if (!this.busy) return;
    const pid = this.state.pid;
    this.setState({ phase: 'stopping', title: pid ? 'Fermeture de Minecraft' : 'Annulation du lancement', progress: null });
    ++this.generation;
    clearInterval(this.watchdog);
    const worker = this.worker;
    if (worker) {
      await new Promise(resolve => {
        const timer = setTimeout(resolve, 5000);
        worker.once('exit', () => { clearTimeout(timer); resolve(); });
        try { worker.postMessage({ type: 'stop' }); }
        catch { clearTimeout(timer); resolve(); }
      });
    }
    if (pid) {
      if (process.platform === 'win32') await new Promise(resolve => execFile('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true, timeout: 10000 }, () => resolve()));
      else { try { process.kill(pid, 'SIGTERM'); } catch { /* Already closed. */ } }
    }
    worker?.kill();
    this.worker = null;
    this.log('Lancement annule ou jeu arrete par le joueur.');
    this.setState({ phase: 'idle', title: 'Lancement arrete', detail: 'Tu peux relancer Minecraft.', progress: null, error: null, pid: null, speed: 0 });
    this.onClosed();
  }
}

module.exports = { MinecraftLauncher };