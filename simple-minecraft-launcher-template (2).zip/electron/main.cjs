const { app, BrowserWindow, ipcMain, shell, dialog, session } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const http = require('node:http');
const { pathToFileURL } = require('node:url');
const { MicrosoftAccount } = require('./auth.cjs');
const { MinecraftLauncher } = require('./minecraft.cjs');

app.setName('Dofus Craft');
app.setPath('userData', path.join(app.getPath('appData'), 'dofus-craft'));
let mainWindow;
let launcher;
let account;
let allowClose = false;
let closePrompt = false;
let rendererURL = '';

function handle(channel, callback) {
  ipcMain.handle(channel, async (event, ...args) => {
    if (!mainWindow || event.sender !== mainWindow.webContents || event.senderFrame !== mainWindow.webContents.mainFrame) return { ok: false, error: 'Requete non autorisee.' };
    try { return { ok: true, data: await callback(...args) }; }
    catch (error) { return { ok: false, error: error.message || String(error) }; }
  });
}
function notify(channel, payload) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send(channel, payload);
  if (channel === 'launcher:state') {
    const installing = ['authenticating', 'preparing', 'downloading', 'launching'].includes(payload.phase);
    mainWindow.setProgressBar(installing ? payload.progress === null ? 2 : payload.progress / 100 : -1);
  }
}
function openExternal(url) {
  try {
    const parsed = new URL(url);
    if (['https:', 'http:'].includes(parsed.protocol)) shell.openExternal(parsed.href).catch(() => {});
  } catch { /* Ignore malformed links. */ }
}
function viteAvailable() {
  return new Promise(resolve => {
    const request = http.get('http://localhost:5173/@vite/client', response => { response.resume(); resolve(response.statusCode === 200); });
    request.setTimeout(1200, () => { request.destroy(); resolve(false); });
    request.on('error', () => resolve(false));
  });
}

async function createWindow() {
  const imageRoot = path.join(__dirname, app.isPackaged ? '../dist/images' : '../public/images');
  let icon;
  for (const name of ['app-icon.png', 'logo.png', 'emerald-item.png']) {
    const file = path.join(imageRoot, name);
    if (await fs.access(file).then(() => true).catch(() => false)) { icon = file; break; }
  }
  mainWindow = new BrowserWindow({
    width: 1440, height: 900, minWidth: 980, minHeight: 660,
    title: 'Dofus Craft', frame: false, backgroundColor: '#0c100d', show: false,
    autoHideMenuBar: true, icon,
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true },
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => { openExternal(url); return { action: 'deny' }; });
  mainWindow.webContents.on('will-navigate', (event, url) => { if (url !== rendererURL) { event.preventDefault(); openExternal(url); } });
  mainWindow.on('close', async event => {
    if (allowClose || !launcher?.busy) return;
    event.preventDefault();
    if (closePrompt) return;
    closePrompt = true;
    const answer = await dialog.showMessageBox(mainWindow, { type: 'question', title: 'Quitter Dofus Craft', message: 'Minecraft ou son installation est en cours.', detail: 'Quitter arretera aussi le jeu ou le telechargement.', buttons: ['Garder ouvert', 'Arreter et quitter'], defaultId: 0, cancelId: 0 });
    closePrompt = false;
    if (answer.response === 1) { await launcher.stop(); allowClose = true; app.quit(); }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  const lifecycle = process.env.npm_lifecycle_event;
  const useDev = !app.isPackaged && !process.argv.includes('--preview') && lifecycle !== 'electron:preview' && await viteAvailable();
  if (useDev) {
    rendererURL = 'http://localhost:5173/';
    await mainWindow.loadURL(rendererURL);
  } else {
    if (lifecycle === 'electron:dev' || process.argv.includes('--dev')) throw new Error("Vite n'est pas accessible sur le port 5173. Ferme les autres instances et relance npm run electron:dev.");
    const entry = path.join(__dirname, '../dist/index.html');
    rendererURL = pathToFileURL(entry).href;
    await mainWindow.loadFile(entry);
  }
  if (process.argv.includes('--debug')) mainWindow.webContents.openDevTools({ mode: 'detach' });
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { mainWindow?.show(); mainWindow?.focus(); });
  app.whenReady().then(async () => {
    account = new MicrosoftAccount(app.getPath('userData'));
    await account.restore();
    launcher = new MinecraftLauncher({
      directory: app.getPath('userData'), account, notify,
      onStarted: hide => { mainWindow?.setProgressBar(-1); if (hide) mainWindow?.hide(); },
      onClosed: () => { mainWindow?.setProgressBar(-1); mainWindow?.show(); },
    });
    session.defaultSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    handle('account:session', () => account.profile);
    handle('account:login', () => { if (launcher.busy) throw new Error('Arrete Minecraft avant de changer de compte.'); return account.login(mainWindow); });
    handle('account:logout', async () => {
      if (launcher.busy) throw new Error('Arrete Minecraft avant de te deconnecter.');
      await account.logout();
      await session.fromPartition('persist:dofus-microsoft').clearStorageData();
      return null;
    });
    handle('launcher:snapshot', () => launcher.snapshot());
    handle('launcher:launch', options => {
      try { return launcher.launch(options); }
      catch (error) { if (!launcher.busy) launcher.fail(error.message); throw error; }
    });
    handle('launcher:stop', () => launcher.stop());
    handle('launcher:java', async () => {
      const result = await dialog.showOpenDialog(mainWindow, { title: 'Selectionner Java', properties: ['openFile'], ...(process.platform === 'win32' ? { filters: [{ name: 'Java', extensions: ['exe'] }] } : {}) });
      return result.canceled ? null : result.filePaths[0];
    });
    handle('launcher:folder', async kind => {
      if (!['game', 'logs'].includes(kind)) throw new Error('Dossier inconnu.');
      const directory = kind === 'game' ? launcher.rootDir : launcher.logDir;
      await fs.mkdir(directory, { recursive: true });
      const error = await shell.openPath(directory);
      if (error) throw new Error(error);
      return null;
    });
    handle('launcher:export', async () => {
      const result = await dialog.showSaveDialog(mainWindow, { title: 'Exporter le journal', defaultPath: 'dofus-craft-diagnostic.txt', filters: [{ name: 'Journal', extensions: ['txt'] }] });
      if (result.canceled || !result.filePath) return false;
      await fs.writeFile(result.filePath, launcher.logs.map(entry => `${entry.time} [${entry.level}] ${entry.text}`).join('\n'), 'utf8');
      return true;
    });
    handle('window:control', action => {
      if (action === 'minimize') mainWindow?.minimize();
      if (action === 'maximize') { if (mainWindow?.isMaximized()) mainWindow.unmaximize(); else mainWindow?.maximize(); }
      if (action === 'close') mainWindow?.close();
      return null;
    });
    await createWindow();
  }).catch(error => {
    console.error(error);
    dialog.showErrorBox('Dofus Craft - Erreur de demarrage', error.message || String(error));
    app.quit();
  });
  app.on('activate', () => { if (mainWindow) mainWindow.show(); else createWindow().catch(console.error); });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
  app.on('before-quit', event => {
    if (launcher?.busy && !allowClose) { event.preventDefault(); launcher.stop().finally(() => { allowClose = true; app.quit(); }); }
  });
}