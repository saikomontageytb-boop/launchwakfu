# Boutique Dofus Craft

## Ce qui fonctionne

Le catalogue est defini dans `src/config.ts`. Les prix sont exprimes en centimes.
Les articles ont un identifiant stable, une categorie, une description, une image,
des avantages et une quantite maximale. Les grades sont limites a une unite par
panier; les lots de Kamas peuvent etre ajoutes plusieurs fois.

La recherche, les filtres, les fiches articles, l'ajout au panier, la suppression,
les quantites et les totaux fonctionnent sans service externe. Le panier et le
pseudo du beneficiaire sont conserves dans le stockage local de cet appareil.
Ce n'est pas encore un panier synchronise avec un compte marchand.

Les articles sont des exemples. Il n'existe aucune commande payee ou livraison
reelle tant qu'un backend marchand et un plugin serveur ne sont pas connectes.

## Paiement futur

Le point d'integration est `src/services/checkout.ts`. Il ne fait aucun appel tant
que `config.paiement.actif` est faux. Ne jamais mettre de cle secrete de paiement
dans le launcher, le preload ou la configuration publique.

Quand le backend sera pret, configurer :

- `paiement.endpoint` : URL HTTPS de ton endpoint de creation de session.
- `paiement.originesAutorisees` : origines HTTPS exactes des pages de paiement
  hebergees autorisees, par exemple celle du prestataire choisi.
- `paiement.actif` : mettre a vrai seulement apres test du paiement et du webhook.

L'interface envoie un POST JSON contenant `items` (productId, quantity) et
`recipient` (pseudo Minecraft). Elle n'envoie pas de prix faisant autorite et ne
collecte aucune information de carte bancaire. L'endpoint retourne `checkoutUrl`.

## Responsabilites du backend

1. Valider les identifiants, les quantites, le beneficiaire et la disponibilite.
2. Recalculer tous les montants depuis un catalogue de confiance cote serveur.
3. Mettre en place une authentification marchande, une protection contre les
   abus et une politique CORS permettant uniquement les clients attendus.
4. Creer la session chez le prestataire avec une cle conservee uniquement sur
   le serveur. Retourner uniquement l'URL HTTPS de la page de paiement.
5. Traiter les webhooks signes et verifier le paiement cote serveur.
6. Livrer les articles via le plugin serveur de facon idempotente, jamais sur la
   seule foi d'une redirection du navigateur ou d'un total fourni par le client.
7. Gerer les remboursements, les erreurs de livraison, les reçus et l'historique.

Le prototype ne vide pas le panier sur une simple ouverture de page de paiement
et ne pretend jamais qu'un achat est confirme. Une future confirmation doit venir
du backend apres verification du webhook.

Valider les conditions de vente, obligations fiscales et regles de monetisation
Minecraft applicables avant d'ouvrir la boutique. Le projet n'est pas affilie a
Mojang, Microsoft ou Ankama.