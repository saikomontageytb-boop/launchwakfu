# Dofus Craft : demarrage et application de bureau

Le projet contient une interface React et un moteur Electron pour Minecraft
Java Edition **vanilla**. L'interface web ne peut pas executer Java. Elle ne
simule plus un telechargement ou un lancement reussi.

## Demarrer sur Windows

1. Installer Node.js **22.12 ou plus recent** (version LTS recommandee).
2. Ouvrir PowerShell dans le dossier qui contient `package.json`.
3. Fermer les anciennes instances du launcher et du serveur Vite.
4. Installer les dependances, y compris celles de developpement :

```powershell
npm install --include=dev
npm run electron:dev
```

Utiliser les fichiers du projet mis a jour : installer uniquement les nouvelles
dependances sans remplacer les anciens fichiers Electron ne corrige pas le moteur.
Il n'est pas necessaire d'installer Vite globalement.

Si Vite est encore introuvable :

```powershell
node --version
npm config get omit
npm ls vite
npm install --include=dev
```

Ne pas supprimer le lockfile ni utiliser `npm audit fix --force` aveuglement.
Les avertissements de securite doivent etre examines avant une distribution publique.

## Premier lancement de Minecraft

1. Cliquer sur l'avatar et se connecter avec Microsoft.
2. Utiliser un compte qui possede **Minecraft Java Edition**. Un simple pseudo
   local ne permet pas de rejoindre un serveur authentifie.
3. Dans Parametres > Serveur, indiquer l'IP ou le domaine et le port reels.
4. Activer Connexion directe et choisir la version compatible dans l'onglet Jeu.
5. Cliquer sur Jouer maintenant.

Le moteur effectue les operations suivantes :

- Verification ou renouvellement de la session Microsoft.
- Lecture du manifeste officiel Mojang et verification de son SHA-1.
- Recherche d'un Java 64 bits compatible. Si absent, telechargement de Temurin
  depuis Adoptium, verification SHA-256 et installation locale.
- Verification des JAR deja presents et installation des fichiers manquants.
- Demarrage d'un vrai processus Java, avec gestion de l'erreur de creation.
- Transmission de Quick Play pour rejoindre l'adresse configuree.

Les versions 1.21.4, 1.21.1 et 1.20.6 utilisent Java 21. Les versions 1.20.4 et
1.19.4 utilisent Java 17. Le choix exact est lu dans le manifeste officiel.

**Une adresse vide ouvre le menu principal de Minecraft.** Le launcher ne cree
pas de serveur et ne peut pas deviner ton IP. Un serveur eteint, une whitelist,
un pare-feu, une incompatibilite de version ou un modpack manquant peuvent
empecher la connexion meme lorsque le jeu est correctement lance.

Les mods et Forge/Fabric ne sont pas distribues automatiquement dans cette version.

## Suivre ce qui se passe

Le bouton de lancement ouvre un panneau contenant :

- Les etapes Compte, Java, Fichiers et Lancement.
- Le pourcentage **de l'etape courante**, si le moteur connait son total.
- Les octets ou les fichiers traites, le debit disponible et le temps ecoule.
- Un indicateur indetermine pendant les operations sans total connu.
- Le journal detaille et les erreurs, exportables en fichier texte.

Le panneau peut etre ferme sans annuler le telechargement. La barre en bas
permet de le rouvrir. Le bouton Annuler arrete le processus d'installation.
Le bouton Arreter le jeu ferme le processus Minecraft.

"Minecraft est ouvert" n'est affiche qu'apres l'evenement de creation du vrai
processus Java. Cela ne pretend pas que le serveur a accepte la connexion.

Si le jeu se ferme, son code de sortie et sa sortie console restent disponibles.
En cas de blocage, exporter le journal plutot que se fier seulement a la fenetre
PowerShell. Les jetons connus et les arguments sensibles sont masques.

## IP et logo pour tous les joueurs

`src/config.ts` contient le nom, le logo, le fond, l'IP, le port, les versions,
les actualites, le catalogue et les liens.

Pour distribuer l'IP a tous les joueurs, remplir `ip` et `port`, puis recompiler.
Les reglages dans l'application restent des preferences propres a chaque appareil.

Pour le logo :

- Placer le fichier dans `public/images/logo.png`, ou modifier `logo` dans la config.
- Utiliser `images/logo.png` ou `/images/logo.png`, pas un chemin absolu Windows.
- Les chemins `public/images/...` sont aussi normalises par l'interface.
- Un monogramme Dofus Craft s'affiche si le fichier est absent ou invalide.
- Parametres > Apparence permet d'importer un PNG, JPG ou WebP de moins de 2 Mo.
  Cet import est local, pas distribue automatiquement aux autres joueurs.
- Une image du logo doit etre fournie : renommer uniquement le champ du serveur
  ne cree pas ce fichier.

Les images du dossier public sont copiees par Vite dans le build et leurs chemins
sont resolus relativement au document, y compris sous `file://` en Electron.
Les polices sont integrees au build, sans dependance a Google Fonts au demarrage.

## Tester le build de production

```powershell
npm run electron:preview
```

Le moteur detecte cette commande et charge `dist/index.html`, pas le serveur Vite.
En developpement, `electron:dev` doit pouvoir joindre Vite sur le port 5173.

## Generer le .exe

Utiliser le nouveau script de packaging plutot que les anciens scripts
`electron:build:*`, dont la configuration historique contient des chemins
d'icones absentes et des dependances de developpement melangees.

```powershell
npm run build
node scripts/package-desktop.cjs --win
```

Le script genere un manifeste d'application separe dans `.desktop-stage/`, y
installe uniquement les dependances du moteur et lance electron-builder.
Il ne modifie pas le `package.json` ni le `vite.config.ts` du projet React.
Les packages sont places dans `release/`.

Pour les autres plateformes, utiliser `--mac` sur macOS ou `--linux` sur Linux.
Compiler sur la plateforme cible reste la solution recommandee.

L'icone du package peut etre remplacee avec `public/images/app-icon.png`, PNG
carre de 512 x 512 recommande. Sinon, le cristal du launcher sert d'icone.
Les packages ne sont pas signes par un certificat editeur. SmartScreen ou
Gatekeeper peuvent donc afficher un avertissement. La signature et la
notarisation de production restent a configurer avec tes propres certificats.

## Emplacement des donnees

- Windows : `%APPDATA%\dofus-craft\`
- macOS : `~/Library/Application Support/dofus-craft/`
- Linux : le repertoire d'application `dofus-craft` dans le dossier de configuration.

`minecraft/` contient le jeu, `runtime/` les installations Java et
`logs/launcher.log` les diagnostics. Les fichiers `.part` ne sont jamais utilises
comme fichiers de jeu termines.

La session Microsoft est chiffree via `safeStorage` lorsque le systeme fournit
un stockage securise. Les jetons ne sont jamais envoyes au renderer React ni
places dans localStorage. Sans chiffrement disponible, la session n'est pas
conservee sur disque. La deconnexion supprime le fichier et les cookies Microsoft
de la partition de connexion.

## Boutique

Le catalogue, les filtres, les fiches, les quantites et le panier persistant sont
fonctionnels. Aucun paiement, commande payee ou livraison en jeu n'est simule.

La configuration `paiement.actif` reste sur `false`. Lire `BOUTIQUE.md` avant de
connecter un prestataire de paiement. Les tarifs et avantages fournis sont des
exemples a valider pour ton serveur.

## Verifications et limites

Le build Vite de l'interface a ete verifie dans l'environnement de developpement.
Les sessions Microsoft interactives, Java, l'ouverture graphique de Minecraft,
le serveur cible et le packaging Windows doivent etre testes sur une vraie machine.
Il ne faut pas confondre un build web reussi avec un test de jeu reussi.

Tests unitaires et verification syntaxique des fichiers Electron :

```powershell
node --test tests/launcher.test.cjs
```

Ces tests n'ouvrent pas de compte Microsoft et ne lancent pas de jeu. Ils couvrent
les options, Quick Play, les exports des dependances, les secrets et la syntaxe.
Ils sont fournis dans le projet mais n'ont pas pu etre executes dans cet environnement.

Avant publication, faire un `npm audit`, examiner les dependances historiques de
MCLC, tester le premier telechargement et sa reprise apres annulation, le second
lancement en cache, l'authentification, le logo et la connexion au vrai serveur.
L'installation de dependances dans cet environnement signale encore des alertes
de securite transitives. Elles ne doivent pas etre ignorees pour une distribution.