import { useEffect } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'framer-motion';
import { ArrowUpRight, CircleAlert, LoaderCircle, Terminal } from 'lucide-react';
import { Toaster } from 'sonner';
import { config } from './config';
import { LauncherProvider, useLauncher } from './state/LauncherContext';
import { ShopProvider } from './state/ShopContext';
import { assetPath } from './utils/assets';
import { IconSidebar, DiscordIcon } from './components/IconSidebar';
import { WindowControls } from './components/WindowControls';
import { HomeView } from './components/HomeView';
import { ShopView } from './components/ShopView';
import { NewsView } from './components/NewsView';
import { BrandLogo } from './components/BrandLogo';
import { LoginModal } from './components/LoginModal';
import { SettingsModal } from './components/SettingsModal';
import { LaunchProgress } from './components/LaunchProgress';
import { ShopModals } from './components/ShopModals';
import { ContentModals } from './components/ContentModals';

function Shell() {
  const { view, setView, openDiscord, isElectron, launch, busy, setProgressOuvert, setSettingsOuvert, reglages } = useLauncher();
  return <div className="launcher-app">
    <IconSidebar />
    <main className={`launcher-main view-${view}`}>
      <div className="world-background" aria-hidden="true"><motion.img src={assetPath(config.fond)} alt="" initial={{ scale: 1.065 }} animate={{ scale: 1 }} transition={{ duration: 2.2, ease: 'easeOut' }} /><div className="world-shade" /></div>
      <WindowControls />
      <header className="topbar drag-region"><button className="brand-lockup no-drag" onClick={() => setView('home')} aria-label={`${config.nom}, accueil`}><BrandLogo /><span><strong>{config.nom.toUpperCase()}</strong><small>LE LAUNCHER</small></span></button><button className="community-link no-drag" onClick={openDiscord}><DiscordIcon size={18} /><span>Rejoins la communauté</span><ArrowUpRight size={15} /></button></header>
      <div className="main-scroll" key={view}>
        <AnimatePresence mode="wait"><motion.div className="page-content" key={view} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: .22 }}>{view === 'home' ? <HomeView /> : view === 'shop' ? <ShopView /> : <NewsView />}</motion.div></AnimatePresence>
      </div>
      <footer className={`launcher-footer ${busy || launch.phase === 'error' ? 'has-progress' : ''}`}>
        {busy || launch.phase === 'error' ? <button className="footer-progress" onClick={() => setProgressOuvert(true)}><span className={launch.phase === 'error' ? 'error' : ''}>{launch.phase === 'error' ? <CircleAlert size={16} /> : launch.phase === 'running' ? <span className="status-dot green" /> : <LoaderCircle className="spin" size={16} />}{launch.title}</span><span>{launch.progress !== null && launch.phase !== 'running' ? `${launch.progress} %` : 'Voir le journal'}<ArrowUpRight size={13} /></span></button> : <><span className="footer-environment"><span className={`status-dot ${isElectron ? 'green' : ''}`} />{isElectron ? 'Application de bureau' : 'Version web'}</span><button className="footer-server" onClick={() => setSettingsOuvert(true)}>{reglages.serverHost || 'Serveur à configurer'}</button></>}
        <div className="footer-right"><button onClick={() => setProgressOuvert(true)} aria-label="Journal du launcher"><Terminal size={14} /></button><span>v{config.versionLauncher}</span></div>
      </footer>
    </main>
    <LoginModal /><SettingsModal /><LaunchProgress /><ShopModals /><ContentModals />
  </div>;
}

export default function App() {
  useEffect(() => { document.documentElement.style.setProperty('--accent', config.couleurAccent); document.title = `${config.nom} - Launcher`; }, []);
  return <MotionConfig reducedMotion="user"><LauncherProvider><ShopProvider><Shell /><Toaster theme="dark" position="bottom-right" toastOptions={{ style: { background: '#20271f', color: '#f5f5f0', border: 'none', fontFamily: 'Inter, sans-serif' } }} /></ShopProvider></LauncherProvider></MotionConfig>;
}