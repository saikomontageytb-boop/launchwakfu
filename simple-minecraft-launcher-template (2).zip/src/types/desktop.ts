export type Phase = 'idle' | 'authenticating' | 'preparing' | 'downloading' | 'launching' | 'running' | 'stopping' | 'error';
export interface Player { name: string; uuid: string }
export interface LaunchState {
  phase: Phase;
  stage: 'verification' | 'java' | 'minecraft' | 'launch' | 'ready';
  progress: number | null;
  title: string;
  detail: string;
  error: string | null;
  pid: number | null;
  startedAt: number | null;
  updatedAt: number;
  current: number;
  total: number;
  speed: number;
  unit: 'files' | 'bytes';
}
export interface LogEntry { id: string; time: string; text: string; level: 'info' | 'warn' | 'error' }
export interface LaunchOptions { version: string; ram: number; fullscreen: boolean; hideOnLaunch: boolean; autoJoin: boolean; serverHost: string; serverPort: number; javaPath: string }
export type Result<T> = { ok: true; data: T } | { ok: false; error: string };
export interface DesktopAPI {
  version: number;
  getSession(): Promise<Result<Player | null>>;
  login(): Promise<Result<Player>>;
  logout(): Promise<Result<null>>;
  getLaunchState(): Promise<Result<{ state: LaunchState; logs: LogEntry[] }>>;
  launchMinecraft(options: LaunchOptions): Promise<Result<{ accepted: boolean }>>;
  stopMinecraft(): Promise<Result<void>>;
  chooseJava(): Promise<Result<string | null>>;
  openFolder(kind: 'game' | 'logs'): Promise<Result<null>>;
  exportLogs(): Promise<Result<boolean>>;
  windowControl(action: 'minimize' | 'maximize' | 'close'): Promise<Result<null>>;
  onState(callback: (state: LaunchState) => void): () => void;
  onLog(callback: (log: LogEntry) => void): () => void;
}
declare global { interface Window { electronAPI?: DesktopAPI } }

export function unwrap<T>(result: Result<T>): T {
  if (!result.ok) throw new Error(result.error);
  return result.data;
}