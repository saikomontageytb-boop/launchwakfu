import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { toast } from 'sonner';
import { config, type Actualite } from '../config';
import { unwrap, type LaunchState, type Player, type LogEntry } from '../types/desktop';
import { readStorage, writeStorage } from '../utils/storage';

export interface Reglages {
  ram: number;
  pleinEcran: boolean;
  masquerAuLancement: boolean;
  javaPath: string;
  autoJoin: boolean;
  serverHost: string;
  serverPort: number;
}
export const REGLAGES_DEFAUT: Reglages = { ram: 4, pleinEcran: false, masquerAuLancement: false, javaPath: '', autoJoin: true, serverHost: config.ip, serverPort: config.port };
const INITIAL: LaunchState = { phase: 'idle', stage: 'verification', progress: null, title: 'Prêt pour l’aventure', detail: '', error: null, pid: null, startedAt: null, updatedAt: Date.now(), current: 0, total: 0, speed: 0, unit: 'files' };
export type View = 'home' | 'shop' | 'news';
type Info = 'desktop' | 'community' | 'help' | null;

interface LauncherState {
  view: View; setView: (value: View) => void;
  profile: Player | null; pseudo: string | null;
  loginOuvert: boolean; setLoginOuvert: (value: boolean) => void;
  settingsOuvert: boolean; setSettingsOuvert: (value: boolean) => void;
  progressOuvert: boolean; setProgressOuvert: (value: boolean) => void;
  info: Info; setInfo: (value: Info) => void;
  article: Actualite | null; setArticle: (value: Actualite | null) => void;
  notificationsOuvertes: boolean; setNotificationsOuvertes: (value: boolean) => void;
  reglages: Reglages; majReglages: (value: Partial<Reglages>) => void;
  version: string; setVersion: (value: string) => void;
  customLogo: string | null; setCustomLogo: (value: string | null) => void;
  launch: LaunchState; logs: LogEntry[];
  isElectron: boolean; busy: boolean; authBusy: boolean; authError: string;
  connecter: () => Promise<void>; deconnecter: () => Promise<void>;
  jouer: () => Promise<void>; arreter: () => Promise<void>;
  openDiscord: () => void;
}
const Context = createContext<LauncherState | null>(null);
export function useLauncher() {
  const state = useContext(Context);
  if (!state) throw new Error('LauncherProvider is required');
  return state;
}

export function LauncherProvider({ children }: { children: ReactNode }) {
  const api = window.electronAPI?.version === 2 ? window.electronAPI : undefined;
  const [view, setView] = useState<View>('home');
  const [profile, setProfile] = useState<Player | null>(null);
  const [loginOuvert, setLoginOuvert] = useState(false);
  const [settingsOuvert, setSettingsOuvert] = useState(false);
  const [progressOuvert, setProgressOuvert] = useState(false);
  const [notificationsOuvertes, setNotificationsOuvertes] = useState(false);
  const [article, setArticle] = useState<Actualite | null>(null);
  const [info, setInfo] = useState<Info>(null);
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState('');
  const [reglages, setReglages] = useState<Reglages>(() => {
    const saved = readStorage<Partial<Reglages>>('settings-v2', {});
    return { ...REGLAGES_DEFAUT, ...saved, serverHost: saved.serverHost || config.ip, ram: Math.min(16, Math.max(2, Number(saved.ram) || 4)) };
  });
  const [version, saveVersion] = useState(() => {
    const saved = readStorage<string>('version', config.versionJeu);
    return config.versionsDisponibles.includes(saved) ? saved : config.versionJeu;
  });
  const [customLogo, saveLogo] = useState<string | null>(() => readStorage('logo', null));
  const [launch, setLaunch] = useState<LaunchState>(INITIAL);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const pendingPlay = useRef(false);
  const requestPending = useRef(false);
  const busy = !['idle', 'error'].includes(launch.phase);

  useEffect(() => { writeStorage('settings-v2', reglages); }, [reglages]);
  useEffect(() => { writeStorage('version', version); }, [version]);
  const setCustomLogo = (value: string | null) => {
    if (!writeStorage('logo', value)) { toast.error('Image trop volumineuse pour le stockage local.'); return; }
    saveLogo(value);
  };

  useEffect(() => {
    if (!api) return;
    let active = true;
    const unState = api.onState(state => {
      setLaunch(state);
      if (state.phase === 'error') setProgressOuvert(true);
    });
    const unLog = api.onLog(entry => setLogs(previous => [...previous.slice(-399), entry]));
    Promise.all([api.getSession(), api.getLaunchState()]).then(([session, snapshot]) => {
      if (!active) return;
      setProfile(unwrap(session));
      const data = unwrap(snapshot);
      setLaunch(data.state);
      setLogs(data.logs);
    }).catch(error => { if (active) toast.error(`Connexion au launcher : ${error.message}`); });
    return () => { active = false; unState(); unLog(); };
  }, [api]);

  const startLaunch = useCallback(async () => {
    if (!api || requestPending.current) return;
    requestPending.current = true;
    setProgressOuvert(true);
    setLogs([]);
    setLaunch({ ...INITIAL, phase: 'preparing', title: 'Préparation du lancement', startedAt: Date.now() });
    try {
      unwrap(await api.launchMinecraft({ version, ram: reglages.ram, fullscreen: reglages.pleinEcran, hideOnLaunch: reglages.masquerAuLancement, autoJoin: reglages.autoJoin, serverHost: reglages.serverHost, serverPort: reglages.serverPort, javaPath: reglages.javaPath }));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Le moteur de lancement ne répond pas. Redémarre le launcher.';
      setLaunch(previous => ({ ...previous, phase: 'error', error: message, title: 'Lancement impossible', detail: message, progress: null }));
    } finally { requestPending.current = false; }
  }, [api, version, reglages]);

  const jouer = async () => {
    if (busy) { setProgressOuvert(true); return; }
    if (!api) { setInfo('desktop'); return; }
    if (!profile) { pendingPlay.current = true; setLoginOuvert(true); return; }
    await startLaunch();
  };
  const connecter = async () => {
    if (!api) { setLoginOuvert(false); setInfo('desktop'); return; }
    if (authBusy) return;
    setAuthBusy(true);
    setAuthError('');
    try {
      const player = unwrap(await api.login());
      setProfile(player);
      setLoginOuvert(false);
      toast.success(`Bienvenue, ${player.name} !`);
      if (pendingPlay.current) { pendingPlay.current = false; await startLaunch(); }
    } catch (error) { setAuthError(error instanceof Error ? error.message : 'Connexion Microsoft impossible.'); }
    finally { setAuthBusy(false); }
  };
  const deconnecter = async () => {
    if (!api) return;
    try { unwrap(await api.logout()); setProfile(null); toast.success('Compte déconnecté.'); }
    catch (error) { toast.error(error instanceof Error ? error.message : 'Déconnexion impossible.'); }
  };
  const arreter = async () => {
    if (!api) return;
    try { unwrap(await api.stopMinecraft()); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Impossible d'arrêter le jeu."); }
  };
  const openDiscord = () => {
    if (/^https:\/\//.test(config.liens.discord)) window.open(config.liens.discord, '_blank', 'noopener,noreferrer');
    else setInfo('community');
  };

  return <Context.Provider value={{ view, setView, profile, pseudo: profile?.name ?? null, loginOuvert,
    setLoginOuvert: value => { if (!value) pendingPlay.current = false; setLoginOuvert(value); },
    settingsOuvert, setSettingsOuvert, progressOuvert, setProgressOuvert, notificationsOuvertes, setNotificationsOuvertes,
    info, setInfo, article, setArticle, reglages, majReglages: value => setReglages(previous => ({ ...previous, ...value })),
    version, setVersion: value => { if (!busy && config.versionsDisponibles.includes(value)) saveVersion(value); }, customLogo, setCustomLogo,
    launch, logs, isElectron: !!api, busy, authBusy, authError, connecter, deconnecter, jouer, arreter, openDiscord,
  }}>{children}</Context.Provider>;
}