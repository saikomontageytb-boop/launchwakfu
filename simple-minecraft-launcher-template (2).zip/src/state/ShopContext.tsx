import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { toast } from 'sonner';
import { config, type ArticleBoutique } from '../config';
import { readStorage, writeStorage } from '../utils/storage';

export interface CartLine { id: string; quantite: number }
interface ShopState {
  cart: CartLine[]; count: number; total: number;
  cartOpen: boolean; setCartOpen: (value: boolean) => void;
  product: ArticleBoutique | null; setProduct: (value: ArticleBoutique | null) => void;
  add: (id: string) => void; changeQuantity: (id: string, quantity: number) => void;
  clear: () => void;
  recipient: string; setRecipient: (value: string) => void;
}
const Context = createContext<ShopState | null>(null);
export function useShop() { const value = useContext(Context); if (!value) throw new Error('ShopProvider is required'); return value; }

export function ShopProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>(() => {
    const saved = readStorage<unknown>('cart', []);
    if (!Array.isArray(saved)) return [];
    return config.boutique.flatMap(product => {
      const line = saved.find(item => item?.id === product.id);
      const quantity = Math.floor(Number(line?.quantite));
      return Number.isFinite(quantity) && quantity > 0 ? [{ id: product.id, quantite: Math.min(product.maxQuantite, quantity) }] : [];
    });
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [product, setProduct] = useState<ArticleBoutique | null>(null);
  const [recipient, setRecipient] = useState(() => readStorage<string>('recipient', ''));
  useEffect(() => { writeStorage('cart', cart); }, [cart]);
  useEffect(() => { writeStorage('recipient', recipient); }, [recipient]);
  const total = useMemo(() => cart.reduce((sum, line) => sum + (config.boutique.find(item => item.id === line.id)?.prix || 0) * line.quantite, 0), [cart]);
  const add = (id: string) => {
    const item = config.boutique.find(product => product.id === id);
    if (!item) return;
    const line = cart.find(product => product.id === id);
    if (line && line.quantite >= item.maxQuantite) { toast.info('Cet article est déjà dans ton panier.'); setCartOpen(true); return; }
    setCart(previous => previous.some(line => line.id === id) ? previous.map(line => line.id === id ? { ...line, quantite: Math.min(line.quantite + 1, item.maxQuantite) } : line) : [...previous, { id, quantite: 1 }]);
    toast.success(`${item.nom} ajouté au panier`, { action: { label: 'Voir', onClick: () => setCartOpen(true) } });
  };
  const changeQuantity = (id: string, quantity: number) => {
    const product = config.boutique.find(item => item.id === id);
    if (!product) return;
    setCart(previous => quantity <= 0 ? previous.filter(item => item.id !== id) : previous.map(line => line.id === id ? { ...line, quantite: Math.max(1, Math.min(product.maxQuantite, Math.floor(quantity))) } : line));
  };
  return <Context.Provider value={{ cart, total, count: cart.reduce((sum, line) => sum + line.quantite, 0), cartOpen, setCartOpen, product, setProduct, add, changeQuantity, clear: () => setCart([]), recipient, setRecipient }}>{children}</Context.Provider>;
}