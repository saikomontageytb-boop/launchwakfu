// Relative URLs work both on Vite's origin and Electron's file:// origin.
export function assetPath(value: string | null | undefined): string {
  if (!value) return '';
  if (/^https?:\/\//i.test(value) || /^data:image\//i.test(value)) return value;
  const relative = value.replace(/\\/g, '/').replace(/^\/?public\//, '').replace(/^\/+/, '');
  return new URL(`./${relative}`, document.baseURI).href;
}