export function readStorage<T>(key: string, fallback: T): T {
  try { return JSON.parse(localStorage.getItem(`dofus-craft:${key}`) || 'null') ?? fallback; }
  catch { return fallback; }
}
export function writeStorage(key: string, value: unknown): boolean {
  try { localStorage.setItem(`dofus-craft:${key}`, JSON.stringify(value)); return true; }
  catch { return false; }
}