import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Check, Search, ShoppingBag, X } from 'lucide-react';
import { config, formatPrix, type ArticleBoutique } from '../config';
import { useShop } from '../state/ShopContext';
import { assetPath } from '../utils/assets';

export function ProductArt({ product, className = '' }: { product: ArticleBoutique; className?: string }) {
  return <img className={`product-art ${product.variante || ''} ${className}`} src={assetPath(product.image)} alt={product.nom} draggable={false} />;
}

export function ShopView() {
  const [category, setCategory] = useState('Tout');
  const [search, setSearch] = useState('');
  const { count, cart, setCartOpen, setProduct, add } = useShop();
  const normalize = (value: string) => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const products = config.boutique.filter(product => (category === 'Tout' || category === product.categorie) && normalize(product.nom).includes(normalize(search.trim())));
  return <div className="content-view shop-view">
    <header className="page-heading shop-heading"><div><p className="eyebrow">UN PEU PLUS DE DOFUS CRAFT</p><h1>La boutique<span>.</span></h1><p>Fais le plein de possibilités. Soutiens l'aventure.</p></div><button className="secondary-button cart-trigger" onClick={() => setCartOpen(true)}><ShoppingBag size={18} />Mon panier<span>{count}</span></button></header>
    <div className="shop-toolbar"><div className="category-tabs" aria-label="Catégories">{['Tout', 'Grades', 'Kamas', 'Cosmétiques'].map(item => <button key={item} onClick={() => setCategory(item)} className={category === item ? 'selected' : ''} aria-pressed={category === item}>{item}</button>)}</div>
      <div className="search-field"><Search size={17} /><input aria-label="Rechercher dans la boutique" placeholder="Rechercher un article" value={search} onChange={event => setSearch(event.target.value)} />{search && <button aria-label="Effacer la recherche" onClick={() => setSearch('')}><X size={15} /></button>}</div>
    </div>
    <div className="product-grid">{products.map((product, index) => {
      const inCart = cart.some(line => line.id === product.id);
      return <motion.article className="product-tile" key={product.id} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3, delay: index * .04 }}>
        <button className="product-open" onClick={() => setProduct(product)} aria-label={`Découvrir ${product.nom}`}><span className="product-badge" style={{ color: product.accent }}>{product.badge || product.categorie.toUpperCase()}</span><div className="product-art-area"><ProductArt product={product} /></div><div className="product-copy"><span className="product-category">{product.categorie}</span><h2>{product.nom}</h2><p>{product.description}</p></div></button>
        <div className="product-bottom"><span>{formatPrix(product.prix)}</span><button className={`add-to-cart ${inCart ? 'in-cart' : ''}`} onClick={() => add(product.id)} aria-label={`Ajouter ${product.nom} au panier`}>{inCart ? <Check size={17} /> : <ShoppingBag size={17} />}<span>{inCart ? 'Ajouté' : 'Ajouter'}</span></button></div>
      </motion.article>;
    })}</div>
    {products.length === 0 && <div className="empty-state"><Search size={36} /><h2>Aucun trésor par ici</h2><p>Essaie une autre recherche ou une autre catégorie.</p><button className="text-button" onClick={() => { setSearch(''); setCategory('Tout'); }}>Voir tous les articles <ArrowRight size={16} /></button></div>}
    <p className="store-disclaimer">Le catalogue est en préparation. Les paiements et la livraison en jeu ne sont pas encore activés.</p>
  </div>;
}