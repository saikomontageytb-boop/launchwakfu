import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, ChevronLeft, ChevronRight, CirclePlay, LoaderCircle, Settings, ShoppingBag } from 'lucide-react';
import { config, formatPrix } from '../config';
import { useLauncher } from '../state/LauncherContext';
import { useShop } from '../state/ShopContext';
import { assetPath } from '../utils/assets';

export function HomeView() {
  const { jouer, busy, launch, setSettingsOuvert, version, setView, setArticle } = useLauncher();
  const { setProduct } = useShop();
  const [newsIndex, setNewsIndex] = useState(0);
  const news = config.actualites[newsIndex];
  const product = config.boutique[0];
  return <div className="home-view">
    <section className="home-hero" aria-labelledby="home-title">
      <motion.div className="hero-copy" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, delay: .1 }}>
        <p className="hero-eyebrow"><span />L'AVENTURE COMMENCE ICI</p>
        <h1 id="home-title">{config.nom.split(' ')[0].toUpperCase()}<span>{config.nom.split(' ').slice(1).join(' ').toUpperCase()}</span><i>.</i></h1>
        <p className="hero-description">{config.description}</p>
        <div className="hero-actions">
          <button className="play-button" onClick={jouer}>
            {busy && launch.phase !== 'running' ? <LoaderCircle className="spin" size={24} /> : <CirclePlay size={24} fill="white" stroke="var(--accent)" strokeWidth={1.7} />}
            <span>{launch.phase === 'running' ? 'Jeu en cours' : busy ? 'Lancement en cours' : 'Jouer maintenant'}</span>
          </button>
          <button className="hero-settings icon-button" onClick={() => setSettingsOuvert(true)} aria-label="Paramètres de Minecraft"><Settings size={23} /></button>
        </div>
        <p className="game-version"><span className="little-cube" />Minecraft Java<span className="version-separator" />{version}</p>
      </motion.div>
    </section>

    <motion.section className="home-discover" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6, delay: .3 }} aria-label="Les nouveautés de Dofus Craft">
      <div className="latest-news">
        <div className="section-heading"><h2>Dernières actualités</h2><button onClick={() => setView('news')}>Tout voir <ArrowRight size={14} /></button></div>
        <AnimatePresence mode="wait" initial={false}>
          <motion.button key={news.id} initial={{ opacity: 0, x: 9 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -9 }} transition={{ duration: .2 }} className="news-feature" onClick={() => setArticle(news)}>
            <div className="news-feature-image"><img src={assetPath(news.image)} alt={news.titre} /></div>
            <div className="news-feature-copy"><span className="news-category">{news.categorie}</span><h3>{news.titre}</h3><p>{news.extrait}</p><span className="article-link">Découvrir <ArrowRight size={14} /></span></div>
          </motion.button>
        </AnimatePresence>
        <div className="news-pagination"><span>{news.date}</span><div><button onClick={() => setNewsIndex(index => (index - 1 + config.actualites.length) % config.actualites.length)} aria-label="Actualité précédente"><ChevronLeft size={15} /></button>
          {config.actualites.map((item, index) => <button key={item.id} className={`pagination-dot ${index === newsIndex ? 'selected' : ''}`} onClick={() => setNewsIndex(index)} aria-label={`Actualité ${index + 1}`} aria-current={index === newsIndex ? 'true' : undefined} />)}
          <button onClick={() => setNewsIndex(index => (index + 1) % config.actualites.length)} aria-label="Actualité suivante"><ChevronRight size={15} /></button></div></div>
      </div>
      <div className="shop-preview">
        <div className="section-heading"><h2>La boutique</h2><button onClick={() => setView('shop')}>Explorer <ArrowRight size={14} /></button></div>
        <button className="shop-feature" onClick={() => setProduct(product)}>
          <div className="shop-feature-art"><img src={assetPath(product.image)} alt="Cristal Émeraude" /></div>
          <div className="shop-feature-copy"><span className="news-category">DÉMARQUE-TOI</span><h3>Grade<br />Émeraude</h3><p>Une touche de légende.</p><span className="feature-price">{formatPrix(product.prix)}<span className="shop-bag"><ShoppingBag size={16} /></span></span></div>
        </button>
        <p className="shop-preview-note">Soutiens le serveur. Affirme ton style.</p>
      </div>
    </motion.section>
  </div>;
}