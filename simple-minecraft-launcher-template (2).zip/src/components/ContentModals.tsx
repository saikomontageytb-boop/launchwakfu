import { ArrowRight, Copy, Monitor, Settings, Terminal } from 'lucide-react';
import { toast } from 'sonner';
import { config } from '../config';
import { useLauncher } from '../state/LauncherContext';
import { assetPath } from '../utils/assets';
import { Modal } from './Modal';
import { DiscordIcon } from './IconSidebar';

export function ContentModals() {
  const { info, setInfo, article, setArticle, notificationsOuvertes, setNotificationsOuvertes, setSettingsOuvert, setProgressOuvert } = useLauncher();
  const titles = { desktop: "L'aventure se joue en grand.", community: 'On se retrouve bientôt.', help: 'Un coup de main ?' };
  const bridgeMissing = navigator.userAgent.includes('Electron/') && window.electronAPI?.version !== 2;
  return <>
    <Modal open={!!info} onClose={() => setInfo(null)} title={info ? titles[info] : ''} subtitle="DOFUS CRAFT" className="info-modal">
      {info === 'desktop' && bridgeMissing && <p className="inline-error" role="alert">La liaison avec Electron n'est pas chargée. Ferme toutes les fenêtres, vérifie que les fichiers du dossier electron ont été mis à jour, puis relance l'application. Aucun lancement n'a été simulé.</p>}
      {info === 'desktop' && <><div className="info-illustration"><Monitor size={45} strokeWidth={1.25} /></div><p className="dialog-description">Tu explores la version web du launcher. Pour lancer réellement Minecraft, ouvre l'application de bureau depuis le dossier du projet.</p><div className="command-block"><code>npm install --include=dev<br />npm run electron:dev</code><button className="icon-button" aria-label="Copier les commandes" onClick={async () => { try { await navigator.clipboard.writeText('npm install --include=dev\nnpm run electron:dev'); toast.success('Commandes copiées.'); } catch { toast.error('Sélectionne et copie les commandes manuellement.'); } }}><Copy size={17} /></button></div><p className="field-hint">Node.js 22.12 ou plus récent et un compte Microsoft possédant Minecraft Java Edition sont nécessaires. Java est installé automatiquement au premier lancement.</p><button className="secondary-button full-width" onClick={() => { setInfo(null); setSettingsOuvert(true); }}><Settings size={16} />Configurer le launcher</button></>}
      {info === 'community' && <><div className="info-illustration"><DiscordIcon size={48} /></div><p className="dialog-description">Les meilleures aventures se partagent. Le Discord de Dofus Craft sera bientôt accessible depuis le launcher.</p><div className="setup-help"><h3>Tu prépares le serveur ?</h3><p>Ajoute ton lien d'invitation dans <code>src/config.ts</code>, champ <code>liens.discord</code>. Le bouton ouvrira alors directement ta communauté.</p></div></>}
      {info === 'help' && <><div className="help-list"><section><span>01</span><div><h3>Connecte ton compte</h3><p>Clique sur ton avatar et utilise le compte Microsoft qui possède Minecraft Java.</p></div></section><section><span>02</span><div><h3>Configure ton serveur</h3><p>Dans Paramètres, onglet Serveur, indique ton IP et active la connexion directe.</p></div></section><section><span>03</span><div><h3>Lance l'aventure</h3><p>Java et les fichiers du jeu se téléchargent au premier lancement. Les étapes et les erreurs restent visibles dans le journal.</p></div></section></div><div className="dialog-actions"><button className="secondary-button" onClick={() => { setInfo(null); setProgressOuvert(true); }}><Terminal size={16} />Voir le journal</button><button className="primary-button" onClick={() => { setInfo(null); setSettingsOuvert(true); }}>Paramètres <ArrowRight size={16} /></button></div></>}
    </Modal>
    <Modal open={!!article} onClose={() => setArticle(null)} title={article?.titre || ''} subtitle={article?.categorie} className="article-modal">
      {article && <><img className="article-hero" src={assetPath(article.image)} alt={article.titre} /><p className="article-date">{article.date} · Équipe Dofus Craft</p><div className="article-body">{article.contenu.map(paragraph => <p key={paragraph}>{paragraph}</p>)}</div></>}
    </Modal>
    <Modal open={notificationsOuvertes} onClose={() => setNotificationsOuvertes(false)} title="Quoi de neuf ?" subtitle="LE FIL DE DOFUS CRAFT" className="notifications-modal">
      <div className="notification-list">{config.actualites.map(item => <button key={item.id} onClick={() => { setNotificationsOuvertes(false); setArticle(item); }}><span className="notification-bullet" /><div><span>{item.date}</span><h3>{item.titre}</h3><p>{item.extrait}</p></div><ArrowRight size={18} /></button>)}</div>
    </Modal>
  </>;
}