import { Bell, CircleHelp, Newspaper, Settings2, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLauncher, type View } from '../state/LauncherContext';
import { useShop } from '../state/ShopContext';
import { Avatar } from './Avatar';
import { BrandLogo } from './BrandLogo';

export function DiscordIcon({ size = 20 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.7 5.1a18 18 0 0 0-4.4-1.4l-.5 1a16.6 16.6 0 0 0-5.6 0l-.5-1a18 18 0 0 0-4.4 1.4C1.5 9.2.8 13.3 1.2 17.3a18 18 0 0 0 5.4 2.8l1.1-1.8-1.7-.8.4-.3a12.7 12.7 0 0 0 11.2 0l.4.3-1.7.8 1.1 1.8a18 18 0 0 0 5.4-2.8c.5-4.6-.8-8.6-3.1-12.2ZM8.5 14.8c-1.1 0-1.9-1-1.9-2.2s.8-2.2 1.9-2.2 1.9 1 1.9 2.2-.8 2.2-1.9 2.2Zm7 0c-1.1 0-1.9-1-1.9-2.2s.8-2.2 1.9-2.2 1.9 1 1.9 2.2-.8 2.2-1.9 2.2Z" /></svg>;
}

export function IconSidebar() {
  const { view, setView, pseudo, setLoginOuvert, setSettingsOuvert, setNotificationsOuvertes, setInfo, openDiscord } = useLauncher();
  const { count } = useShop();
  const nav: { id: View; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Accueil', icon: <BrandLogo /> },
    { id: 'shop', label: 'Boutique', icon: <ShoppingBag size={24} /> },
    { id: 'news', label: 'Actualités', icon: <Newspaper size={24} /> },
  ];
  return <aside className="icon-sidebar">
    <button className="profile-button" onClick={() => setLoginOuvert(true)} aria-label={pseudo ? `Compte de ${pseudo}` : 'Se connecter'} title={pseudo || 'Se connecter'}>
      <Avatar pseudo={pseudo} taille={48} /><span className={`profile-dot ${pseudo ? 'connected' : ''}`} />
    </button>
    <span className="profile-caption">{pseudo || 'TON COMPTE'}</span>
    <nav className="side-nav" aria-label="Navigation principale">
      {nav.map(item => <div className="side-nav-item" key={item.id}>
        {view === item.id && <motion.span layoutId="sidebar-indicator" className="active-indicator" transition={{ type: 'spring', stiffness: 420, damping: 32 }} />}
        <button className={`nav-button ${view === item.id ? 'active' : ''}`} onClick={() => setView(item.id)} aria-label={item.label} aria-current={view === item.id ? 'page' : undefined}>
          {item.icon}{item.id === 'shop' && count > 0 && <span className="nav-count">{count}</span>}
        </button>
        <span className="nav-tooltip">{item.label}</span>
      </div>)}
      <div className="side-nav-separator" />
      <div className="side-nav-item"><button className="nav-button" onClick={openDiscord} aria-label="Notre Discord"><DiscordIcon size={24} /></button><span className="nav-tooltip">Discord</span></div>
    </nav>
    <div className="sidebar-bottom">
      <button className="nav-button notification-button" onClick={() => setNotificationsOuvertes(true)} aria-label="Notifications"><Bell size={22} /><span className="notification-dot" /></button>
      <button className="nav-button" onClick={() => setSettingsOuvert(true)} aria-label="Paramètres"><Settings2 size={22} /></button>
      <button className="nav-button help-button" onClick={() => setInfo('help')} aria-label="Aide"><CircleHelp size={19} /></button>
    </div>
  </aside>;
}