import { Maximize2, Minus, Square, X } from 'lucide-react';
import { useLauncher } from '../state/LauncherContext';
import { toast } from 'sonner';

export function WindowControls() {
  const { isElectron } = useLauncher();
  if (!isElectron) return <div className="window-controls web-controls"><span>APERÇU WEB</span><button aria-label="Basculer en plein écran" onClick={async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); }
    catch { toast.info('Le plein écran est indisponible dans cet aperçu.'); }
  }}><Maximize2 size={12} /></button></div>;
  return <div className="window-controls no-drag">
    <button aria-label="Réduire la fenêtre" onClick={() => window.electronAPI?.windowControl('minimize')}><Minus size={14} /></button>
    <button aria-label="Agrandir la fenêtre" onClick={() => window.electronAPI?.windowControl('maximize')}><Square size={11} /></button>
    <button className="window-close" aria-label="Fermer le launcher" onClick={() => window.electronAPI?.windowControl('close')}><X size={15} /></button>
  </div>;
}