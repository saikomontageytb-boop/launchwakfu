import { useRef, useState, type ChangeEvent, type CSSProperties } from 'react';
import { Check, FolderOpen, ImagePlus, RotateCcw } from 'lucide-react';
import { config } from '../config';
import { REGLAGES_DEFAUT, useLauncher } from '../state/LauncherContext';
import { unwrap } from '../types/desktop';
import { Modal } from './Modal';
import { BrandLogo } from './BrandLogo';

function Toggle({ checked, onChange, label, disabled = false }: { checked: boolean; onChange: () => void; label: string; disabled?: boolean }) {
  return <button className={`toggle ${checked ? 'checked' : ''}`} role="switch" aria-checked={checked} aria-label={label} onClick={onChange} disabled={disabled}><span /></button>;
}

export function SettingsModal() {
  const { settingsOuvert, setSettingsOuvert, reglages, majReglages, version, setVersion, customLogo, setCustomLogo, isElectron, busy } = useLauncher();
  const [tab, setTab] = useState('Jeu');
  const [error, setError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const chooseJava = async () => {
    if (!window.electronAPI) { setError("La sélection d'un exécutable Java est disponible dans l'application de bureau."); return; }
    try { const path = unwrap(await window.electronAPI.chooseJava()); if (path) majReglages({ javaPath: path }); }
    catch (error) { setError(error instanceof Error ? error.message : 'Sélection impossible.'); }
  };
  const uploadLogo = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) { setError('Choisis une image PNG, JPG ou WebP de moins de 2 Mo.'); return; }
    const reader = new FileReader();
    reader.onload = () => { setCustomLogo(String(reader.result)); setError(''); };
    reader.onerror = () => setError('Cette image ne peut pas être lue.');
    reader.readAsDataURL(file);
    event.target.value = '';
  };
  return <Modal open={settingsOuvert} onClose={() => setSettingsOuvert(false)} title="À ta façon." subtitle="PARAMÈTRES DU LAUNCHER" className="settings-modal">
    <div className="settings-tabs" role="tablist" aria-label="Paramètres">{['Jeu', 'Serveur', 'Apparence'].map(item => <button key={item} role="tab" aria-selected={item === tab} aria-controls="settings-panel" className={item === tab ? 'selected' : ''} onClick={() => { setTab(item); setError(''); }}>{item}</button>)}</div>
    {error && <p className="inline-error" role="alert">{error}</p>}
    <div id="settings-panel" role="tabpanel" className="settings-panel">
      {tab === 'Jeu' && <>
        <div className="settings-field"><label htmlFor="ram" className="field-heading">Mémoire allouée <strong>{reglages.ram} <small>Go</small></strong></label><input id="ram" type="range" min="2" max="16" step="1" value={reglages.ram} disabled={busy} onChange={event => majReglages({ ram: Number(event.target.value) })} style={{ '--fill': `${(reglages.ram - 2) / 14 * 100}%` } as CSSProperties} /><div className="range-labels"><span>2 Go</span><span>16 Go</span></div><p className="field-hint">4 Go suffisent pour Minecraft vanilla. Garde de la mémoire pour Windows.</p></div>
        <div className="settings-field"><label htmlFor="game-version">Version de Minecraft</label><select id="game-version" value={version} onChange={event => setVersion(event.target.value)} disabled={busy}>{config.versionsDisponibles.map(item => <option key={item}>{item}</option>)}</select></div>
        <div className="setting-toggle"><div><h3>Plein écran</h3><p>Profite de chaque pixel de ton aventure.</p></div><Toggle checked={reglages.pleinEcran} onChange={() => majReglages({ pleinEcran: !reglages.pleinEcran })} label="Lancer en plein écran" disabled={busy} /></div>
        <div className="setting-toggle"><div><h3>Masquer le launcher pendant le jeu</h3><p>Il réapparaît lorsque Minecraft se ferme.</p></div><Toggle checked={reglages.masquerAuLancement} onChange={() => majReglages({ masquerAuLancement: !reglages.masquerAuLancement })} label="Masquer le launcher pendant le jeu" disabled={busy} /></div>
        <div className="settings-field"><label htmlFor="java-path">Java <span className="muted">facultatif</span></label><div className="input-action"><input id="java-path" value={reglages.javaPath} onChange={event => majReglages({ javaPath: event.target.value })} placeholder="Installation automatique" disabled={busy} /><button className="icon-button" onClick={chooseJava} aria-label="Choisir l'exécutable Java" disabled={busy}><FolderOpen size={18} /></button></div><p className="field-hint">Laisse vide pour installer automatiquement Java 21 ou 17 selon la version du jeu.</p></div>
        {isElectron && <button className="secondary-button" onClick={async () => { try { unwrap(await window.electronAPI!.openFolder('game')); } catch (error) { setError(String(error)); } }}><FolderOpen size={16} />Ouvrir le dossier du jeu</button>}
      </>}
      {tab === 'Serveur' && <>
        <p className="dialog-description">Un seul monde, un accès direct. Indique l'adresse de ton serveur pour le rejoindre au démarrage.</p>
        <div className="settings-field"><label htmlFor="server-ip">Adresse du serveur</label><input id="server-ip" value={reglages.serverHost} onChange={event => majReglages({ serverHost: event.target.value.trim() })} placeholder="play.mondomaine.fr" disabled={busy} spellCheck={false} autoComplete="off" /><p className="field-hint">L'IP réelle ou le domaine, sans https:// ni port.</p></div>
        <div className="settings-field"><label htmlFor="server-port">Port</label><input id="server-port" type="number" min="1" max="65535" value={reglages.serverPort || ''} onChange={event => majReglages({ serverPort: Number(event.target.value) })} disabled={busy} /></div>
        <div className="setting-toggle"><div><h3>Connexion directe</h3><p>Rejoindre Dofus Craft avec Quick Play.</p></div><Toggle checked={reglages.autoJoin} onChange={() => majReglages({ autoJoin: !reglages.autoJoin })} label="Rejoindre automatiquement le serveur" disabled={busy} /></div>
        {!reglages.serverHost && <p className="inline-note">Sans adresse, Minecraft s'ouvre normalement sur son menu principal.</p>}
        <p className="field-hint">Pour distribuer la même adresse à tous les joueurs, configure <code>ip</code> et <code>port</code> dans <code>src/config.ts</code>. Le serveur doit être compatible avec la version choisie.</p>
      </>}
      {tab === 'Apparence' && <>
        <div className="logo-upload-preview"><BrandLogo /><div><h3>Dofus Craft</h3><p>Ton identité, dans tout le launcher.</p></div></div>
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={uploadLogo} className="visually-hidden" aria-label="Importer un logo" />
        <button className="primary-button full-width" onClick={() => fileRef.current?.click()}><ImagePlus size={18} />Importer mon logo</button>
        <p className="field-hint">PNG transparent conseillé. JPG ou WebP acceptés, 2 Mo maximum. Enregistré uniquement sur cet appareil.</p>
        {customLogo && <button className="text-button" onClick={() => setCustomLogo(null)}><RotateCcw size={15} />Utiliser le logo de la configuration</button>}
        <div className="setup-help"><h3>Un logo pour tous les joueurs</h3><p>Place ton image dans <code>public/images/logo.png</code>, ou change <code>logo</code> dans <code>src/config.ts</code>. Recompile ensuite l'application. Les chemins sont compatibles avec la version de bureau.</p></div>
      </>}
    </div>
    <footer className="settings-footer"><span><Check size={14} />Enregistrement automatique</span><button className="text-button" disabled={busy} onClick={() => { majReglages(REGLAGES_DEFAUT); setVersion(config.versionJeu); }}>Réinitialiser</button></footer>
  </Modal>;
}