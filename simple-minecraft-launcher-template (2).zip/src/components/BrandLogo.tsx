import { useEffect, useMemo, useState } from 'react';
import { Gem } from 'lucide-react';
import { config } from '../config';
import { useLauncher } from '../state/LauncherContext';
import { assetPath } from '../utils/assets';

export function BrandLogo({ className = '' }: { className?: string }) {
  const { customLogo } = useLauncher();
  const sources = useMemo(() => [...new Set([
    customLogo, assetPath(config.logo), assetPath('images/logo.svg'), assetPath('logo.png'), assetPath('logo.svg'), assetPath('images/dofus-mark.svg'),
  ].filter((value): value is string => !!value))], [customLogo, config.logo]);
  const [index, setIndex] = useState(0);
  useEffect(() => setIndex(0), [sources]);
  if (index >= sources.length) return <Gem className={`brand-logo ${className}`} aria-label={config.nom} />;
  const defaultMark = sources[index] === assetPath('images/dofus-mark.svg');
  return <img className={`brand-logo ${defaultMark ? 'default-mark' : ''} ${className}`} src={sources[index]} onError={() => setIndex(value => value + 1)} alt={config.nom} draggable={false} />;
}