import { useEffect, useId, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

export function Modal({ open, onClose, title, subtitle, children, className = '', drawer = false }: {
  open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode; className?: string; drawer?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const id = useId();
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);
  return <dialog ref={ref} aria-labelledby={id} className={`modal-shell ${drawer ? 'drawer' : ''} ${className}`}
    onCancel={event => { event.preventDefault(); onClose(); }}
    onClick={event => { if (event.target === ref.current) onClose(); }}>
    {open && <div className="dialog-panel">
      <header className="dialog-header">
        <div>{subtitle && <p className="eyebrow">{subtitle}</p>}<h2 id={id}>{title}</h2></div>
        <button className="icon-button" onClick={onClose} aria-label="Fermer"><X size={21} /></button>
      </header>
      <div className="dialog-body">{children}</div>
    </div>}
  </dialog>;
}