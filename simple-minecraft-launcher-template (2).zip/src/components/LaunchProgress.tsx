import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Check, CheckCircle2, ChevronDown, Download, LoaderCircle, RotateCcw, Settings, Square, Terminal } from 'lucide-react';
import { useLauncher } from '../state/LauncherContext';
import { unwrap } from '../types/desktop';
import { Modal } from './Modal';

const stages = ['verification', 'java', 'minecraft', 'launch', 'ready'];
const bytes = (value: number) => `${(value / 1024 / 1024).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} Mo`;

export function LaunchProgress() {
  const { launch, logs, progressOuvert, setProgressOuvert, isElectron, busy, arreter, jouer, setSettingsOuvert } = useLauncher();
  const [details, setDetails] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [exportError, setExportError] = useState('');
  const logRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (!busy) return; const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); }, [busy]);
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [logs, details]);
  const stage = stages.indexOf(launch.stage);
  const elapsed = launch.startedAt ? Math.max(0, Math.floor((now - launch.startedAt) / 1000)) : 0;
  const running = launch.phase === 'running';
  const error = launch.phase === 'error';
  const exportLogs = async () => {
    try {
      if (isElectron) unwrap(await window.electronAPI!.exportLogs());
      else {
        const url = URL.createObjectURL(new Blob([logs.map(entry => `${entry.time} [${entry.level}] ${entry.text}`).join('\n')], { type: 'text/plain' }));
        const link = document.createElement('a'); link.href = url; link.download = 'dofus-craft-diagnostic.txt'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
    } catch (error) { setExportError(error instanceof Error ? error.message : 'Export impossible.'); }
  };
  return <Modal open={progressOuvert} onClose={() => setProgressOuvert(false)} title={error ? 'Un petit contretemps.' : running ? 'À toi de jouer.' : busy ? "L'aventure se prépare." : 'Journal du launcher'} subtitle="LANCEMENT DE MINECRAFT" className="progress-modal">
    <div className="launch-steps">{['Compte', 'Java', 'Fichiers', 'Lancement'].map((label, index) => <div key={label} className={`${index < stage ? 'complete' : index === stage ? 'current' : ''}`}><span>{index < stage ? <Check size={14} /> : `0${index + 1}`}</span><p>{label}</p></div>)}</div>
    <div className={`progress-status ${error ? 'has-error' : ''}`} aria-live="polite">
      <div className="progress-title">{error ? <AlertCircle size={22} /> : running ? <CheckCircle2 size={23} /> : busy ? <LoaderCircle className="spin" size={22} /> : <Terminal size={22} />}<h3>{launch.title}</h3></div>
      <p>{launch.detail || "Lance Minecraft pour voir les étapes et les diagnostics en temps réel."}</p>
    </div>
    {!error && busy && !running && <>
      <div className="progress-caption"><span>Progression de l'étape</span><strong>{launch.progress === null ? 'En cours' : `${launch.progress} %`}</strong></div>
      <div className={`progress-track ${launch.progress === null ? 'indeterminate' : ''}`} role="progressbar" aria-label={launch.title} aria-valuemin={0} aria-valuemax={100} aria-valuenow={launch.progress ?? undefined}><span style={launch.progress !== null ? { width: `${Math.max(0, Math.min(100, launch.progress))}%` } : undefined} /></div>
      <div className="progress-metrics"><span>{launch.total > 0 ? launch.unit === 'bytes' ? `${bytes(launch.current)} / ${bytes(launch.total)}` : `${launch.current} / ${launch.total} fichiers` : 'Vérification en cours'}{launch.speed > 0 ? ` · ${bytes(launch.speed)}/s` : ''}</span><span>{Math.floor(elapsed / 60)} min {String(elapsed % 60).padStart(2, '0')} s</span></div>
      <p className="field-hint">Le premier lancement peut prendre plusieurs minutes. Tu peux continuer à parcourir le launcher.</p>
    </>}
    {running && <p className="inline-note success">Le processus Java est démarré{launch.pid ? ` (PID ${launch.pid})` : ''}. La connexion au serveur se poursuit dans Minecraft.</p>}
    {exportError && <p className="inline-error">{exportError}</p>}
    <button className="log-toggle" onClick={() => setDetails(value => !value)} aria-expanded={details}><span><Terminal size={16} />Journal détaillé <small>{logs.length} lignes</small></span><ChevronDown size={17} className={details ? 'rotated' : ''} /></button>
    {details && <div className="launch-log" ref={logRef} role="log" aria-label="Journal de lancement">{logs.length ? logs.map(entry => <p key={entry.id} className={entry.level}><time>{new Date(entry.time).toLocaleTimeString('fr-FR')}</time><span>{entry.text}</span></p>) : <p>Aucun lancement enregistré dans cette session.</p>}</div>}
    <div className="progress-actions"><button className="secondary-button" onClick={exportLogs} disabled={!logs.length}><Download size={16} />Exporter le journal</button>
      {error ? <><button className="icon-button" onClick={() => { setProgressOuvert(false); setSettingsOuvert(true); }} aria-label="Ouvrir les paramètres"><Settings size={18} /></button><button className="primary-button" onClick={jouer}><RotateCcw size={16} />Réessayer</button></> : busy ? <button className="text-button danger" onClick={arreter} disabled={launch.phase === 'stopping'}><Square size={13} />{running ? 'Arrêter le jeu' : 'Annuler'}</button> : <button className="primary-button" onClick={() => setProgressOuvert(false)}>Fermer</button>}
    </div>
  </Modal>;
}