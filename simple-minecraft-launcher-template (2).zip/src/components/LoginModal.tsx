import { CheckCircle2, LoaderCircle, LogOut, ShieldCheck } from 'lucide-react';
import { useLauncher } from '../state/LauncherContext';
import { Modal } from './Modal';
import { Avatar } from './Avatar';

export function LoginModal() {
  const { loginOuvert, setLoginOuvert, profile, connecter, deconnecter, authBusy, authError, isElectron, busy } = useLauncher();
  return <Modal open={loginOuvert} onClose={() => setLoginOuvert(false)} title="Ton compte Minecraft" subtitle="BIENVENUE DANS DOFUS CRAFT" className="account-modal">
    {profile ? <div className="account-identity"><Avatar pseudo={profile.name} taille={64} /><div><h3>{profile.name}</h3><p><CheckCircle2 size={14} />Compte Microsoft</p></div></div> : <div className="account-welcome"><Avatar pseudo={null} taille={72} /><p>Une aventure unique.<br /><strong>Un compte qui t'appartient.</strong></p></div>}
    <p className="dialog-description">Connecte le compte Microsoft qui possède Minecraft Java Edition. Ton mot de passe est saisi uniquement chez Microsoft, jamais dans le launcher.</p>
    {authError && <p className="inline-error" role="alert">{authError}</p>}
    {authBusy && <p className="inline-note"><LoaderCircle size={16} className="spin" />Termine la connexion dans la fenêtre Microsoft.</p>}
    <button className="primary-button full-width microsoft-button" disabled={authBusy || busy} onClick={connecter}>
      {authBusy ? <LoaderCircle size={19} className="spin" /> : <span className="microsoft-mark"><i /><i /><i /><i /></span>}
      {isElectron ? profile ? 'Changer de compte' : 'Se connecter avec Microsoft' : "Jouer dans l'application"}
    </button>
    {profile && <button className="text-button signout" onClick={deconnecter} disabled={busy || authBusy}><LogOut size={15} />Se déconnecter</button>}
    <p className="secure-note"><ShieldCheck size={16} />Les identifiants restent hors de l'interface.</p>
  </Modal>;
}