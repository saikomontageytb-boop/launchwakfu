import { useEffect, useState } from 'react';
import { assetPath } from '../utils/assets';

export function Avatar({ pseudo, taille = 44, className = '' }: { pseudo: string | null; taille?: number; className?: string }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [pseudo]);
  const fallback = assetPath('images/avatar-default.png');
  return <img src={pseudo && !failed ? `https://mc-heads.net/avatar/${encodeURIComponent(pseudo)}/100` : fallback}
    width={taille} height={taille} className={`avatar ${className}`} onError={() => setFailed(true)} alt={pseudo || 'Profil Minecraft'} draggable={false} />;
}