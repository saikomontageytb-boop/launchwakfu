import { useState } from 'react';
import { ArrowRight, Check, Clock3, LoaderCircle, LockKeyhole, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { config, formatPrix } from '../config';
import { useShop } from '../state/ShopContext';
import { useLauncher } from '../state/LauncherContext';
import { createCheckout } from '../services/checkout';
import { ProductArt } from './ShopView';
import { Modal } from './Modal';

export function ShopModals() {
  const { product, setProduct, add, cartOpen, setCartOpen, cart, count, total, changeQuantity, recipient, setRecipient } = useShop();
  const { setView, pseudo } = useLauncher();
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [error, setError] = useState('');
  const checkout = async () => {
    setCheckoutBusy(true); setError('');
    try { const url = await createCheckout(cart, recipient || pseudo || ''); window.open(url, '_blank', 'noopener,noreferrer'); }
    catch (error) { setError(error instanceof Error ? error.message : 'Paiement indisponible.'); }
    finally { setCheckoutBusy(false); }
  };
  return <>
    <Modal open={!!product} onClose={() => setProduct(null)} title={product?.nom || ''} subtitle={product?.categorie.toUpperCase()} className="product-modal">
      {product && <><div className="product-detail-art"><ProductArt product={product} /></div><p className="dialog-description">{product.description}</p><ul className="product-benefits">{product.avantages.map(item => <li key={item}><Check size={16} />{item}</li>)}</ul><div className="product-detail-bottom"><strong>{formatPrix(product.prix)}</strong><button className="primary-button" onClick={() => { add(product.id); setProduct(null); }}><ShoppingBag size={18} />Ajouter au panier</button></div><p className="secure-note"><Clock3 size={14} />Catalogue en préparation. Aucun débit pour le moment.</p></>}
    </Modal>
    <Modal open={cartOpen} onClose={() => setCartOpen(false)} title="Ton panier" subtitle={`${count} ARTICLE${count > 1 ? 'S' : ''} POUR TON AVENTURE`} drawer className="cart-modal">
      {!cart.length ? <div className="empty-state"><ShoppingBag size={44} strokeWidth={1.3} /><h3>Les poches sont encore vides.</h3><p>Un trésor t'attend sûrement dans la boutique.</p><button className="primary-button" onClick={() => { setCartOpen(false); setView('shop'); }}>Explorer la boutique <ArrowRight size={16} /></button></div> : <>
        <div className="cart-lines">{cart.map(line => {
          const item = config.boutique.find(product => product.id === line.id)!;
          return <div className="cart-line" key={line.id}><div className="cart-line-art"><ProductArt product={item} /></div><div className="cart-line-main"><span>{item.categorie}</span><h3>{item.nom}</h3><div className="quantity-control"><button aria-label={`Retirer une unité de ${item.nom}`} onClick={() => changeQuantity(item.id, line.quantite - 1)}><Minus size={13} /></button><span>{line.quantite}</span><button aria-label={`Ajouter une unité de ${item.nom}`} onClick={() => changeQuantity(item.id, line.quantite + 1)} disabled={line.quantite >= item.maxQuantite}><Plus size={13} /></button></div></div><div className="cart-line-price"><strong>{formatPrix(item.prix * line.quantite)}</strong><button aria-label={`Supprimer ${item.nom}`} onClick={() => changeQuantity(item.id, 0)}><Trash2 size={16} /></button></div></div>;
        })}</div>
        <div className="settings-field cart-recipient"><label htmlFor="recipient">Pseudo Minecraft du bénéficiaire</label><input id="recipient" value={recipient || pseudo || ''} onChange={event => setRecipient(event.target.value.replace(/[^A-Za-z0-9_]/g, ''))} maxLength={16} placeholder="Ton pseudo en jeu" autoComplete="off" /><p className="field-hint">Pour préparer tes futurs achats. Aucun article n'est encore livré.</p></div>
        <div className="cart-total"><span>Total</span><strong>{formatPrix(total)}</strong></div>
        <div className="payment-notice"><Clock3 size={20} /><div><strong>Les paiements arrivent bientôt</strong><p>Ton panier est sauvegardé sur cet appareil. Aucun paiement ne sera effectué.</p></div></div>
        {error && <p className="inline-error" role="alert">{error}</p>}
        <button className="primary-button full-width checkout-button" onClick={checkout} disabled={!config.paiement.actif || checkoutBusy || !/^[A-Za-z0-9_]{3,16}$/.test(recipient || pseudo || '')}>{checkoutBusy ? <LoaderCircle className="spin" size={17} /> : <LockKeyhole size={17} />}{config.paiement.actif ? 'Passer au paiement' : 'Paiement bientôt disponible'}</button>
        <button className="text-button continue-shopping" onClick={() => { setCartOpen(false); setView('shop'); }}>Continuer mes achats <ArrowRight size={15} /></button>
      </>}
    </Modal>
  </>;
}