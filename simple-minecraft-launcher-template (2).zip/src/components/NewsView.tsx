import { ArrowUpRight } from 'lucide-react';
import { config } from '../config';
import { useLauncher } from '../state/LauncherContext';
import { assetPath } from '../utils/assets';

export function NewsView() {
  const { setArticle } = useLauncher();
  return <div className="content-view news-view">
    <header className="page-heading"><p className="eyebrow">LE JOURNAL DE DOFUS CRAFT</p><h1>Les actualités<span>.</span></h1><p>La suite de l'aventure s'écrit ici.</p></header>
    <div className="news-grid">{config.actualites.map(article => <button key={article.id} className="news-tile" onClick={() => setArticle(article)}>
      <div className="news-tile-image"><img src={assetPath(article.image)} alt={article.titre} /></div>
      <div className="news-tile-copy"><span className="news-category">{article.categorie}</span><h2>{article.titre}</h2><p>{article.extrait}</p><div><time>{article.date}</time><ArrowUpRight size={18} /></div></div>
    </button>)}</div>
  </div>;
}