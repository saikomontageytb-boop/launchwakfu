export interface Actualite {
  id: number;
  titre: string;
  extrait: string;
  contenu: string[];
  image: string;
  date: string;
  categorie: string;
}

export interface ArticleBoutique {
  id: string;
  nom: string;
  categorie: 'Grades' | 'Kamas' | 'Cosmétiques';
  prix: number; // Prix en centimes, jamais en virgule flottante.
  image: string;
  description: string;
  avantages: string[];
  accent: string;
  badge?: string;
  maxQuantite: number;
  variante?: string;
}

export const config = {
  nom: 'Dofus Craft',
  description: 'Un monde à explorer. Une histoire à écrire.\nTon aventure commence sur Dofus Craft.',
  couleurAccent: '#ff751f',
  versionLauncher: '0.2.0',
  // Place ton logo dans public/images/logo.png, ou indique son chemin ici.
  // Les chemins /images/... et public/images/... fonctionnent aussi en .exe.
  logo: 'images/logo.png' as string | null,
  fond: 'images/dofus-world.jpg',
  versionJeu: '1.21.4',
  versionsDisponibles: ['1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.19.4'],
  // Indique l'IP reelle ici, ou dans Parametres > Serveur. Vide = menu du jeu.
  ip: '',
  port: 25565,
  liens: { discord: '', site: '' },
  paiement: {
    actif: false as boolean,
    endpoint: '',
    originesAutorisees: [] as string[],
  },
  actualites: [
    {
      id: 1,
      titre: 'Un nouveau monde vous attend',
      extrait: "Bienvenue dans l'univers de Dofus Craft. L'aventure ne fait que commencer.",
      contenu: [
        'Dofus Craft prend vie, bloc après bloc. Un univers à découvrir, des paysages à explorer et une aventure à construire ensemble.',
        "Le serveur est en préparation. La date d'ouverture, les règles et les premières nouveautés seront annoncées ici. Ces actualités sont personnalisables dans src/config.ts.",
        "En attendant, prépare ton compte Microsoft et règle ton launcher. Lors du premier lancement, Java et les fichiers officiels de Minecraft seront installés automatiquement dans l'application de bureau.",
      ],
      image: 'images/news-ouverture.jpg',
      date: '11 octobre 2026',
      categorie: 'LE DÉBUT DE L\'AVENTURE',
    },
    {
      id: 2,
      titre: 'Votre launcher fait peau neuve',
      extrait: 'Un accès direct au jeu et une expérience repensée pour vous.',
      contenu: [
        'Une nouvelle interface, un journal de lancement et des réglages simplifiés : le launcher évolue.',
        'Le téléchargement des ressources affiche maintenant une progression par étape. Si une erreur survient, ouvre le journal pour voir ce qui bloque et exporter un diagnostic.',
      ],
      image: 'images/dofus-world.jpg',
      date: '10 octobre 2026',
      categorie: 'MISE À JOUR',
    },
    {
      id: 3,
      titre: 'Une aventure, une communauté',
      extrait: 'Les plus belles histoires se construisent à plusieurs.',
      contenu: [
        'Rencontre les futurs aventuriers de Dofus Craft, partage tes constructions et propose tes idées pour le serveur.',
        "Le lien Discord sera ajouté par l'équipe dans la configuration du launcher. La communauté vous accueillera bientôt !",
      ],
      image: 'images/news-communaute.jpg',
      date: '8 octobre 2026',
      categorie: 'COMMUNAUTÉ',
    },
  ] as Actualite[],
  boutique: [
    {
      id: 'grade-emeraude', nom: 'Grade Émeraude', categorie: 'Grades', prix: 1499,
      image: 'images/emerald-item.png', accent: '#9bcf70', badge: 'LE CHOIX DES AVENTURIERS', maxQuantite: 1,
      description: 'Affirme ton style et fais briller ton aventure. Le grade incontournable de Dofus Craft.',
      avantages: ['Préfixe Émeraude dans le chat', 'Couleur de pseudo exclusive', 'Particules émeraude cosmétiques', 'Badge de profil permanent'],
    },
    {
      id: 'grade-aventurier', nom: 'Grade Aventurier', categorie: 'Grades', prix: 499,
      image: 'images/emerald-item.png', accent: '#83b5df', variante: 'blue', maxQuantite: 1,
      description: 'Un premier pas pour soutenir le serveur et personnaliser ton identité.',
      avantages: ['Préfixe Aventurier', 'Badge de soutien', 'Couleur de pseudo personnalisée'],
    },
    {
      id: 'grade-legende', nom: 'Grade Légende', categorie: 'Grades', prix: 2499,
      image: 'images/emerald-item.png', accent: '#e4b970', variante: 'gold', maxQuantite: 1,
      description: "Pour les aventuriers qui veulent laisser leur empreinte dans l'histoire.",
      avantages: ['Préfixe Légende dans le chat', 'Tous les cosmétiques Émeraude', 'Aura dorée exclusive', 'Badge de profil Légende'],
    },
    {
      id: 'kamas-1000', nom: '1 000 Kamas', categorie: 'Kamas', prix: 499,
      image: 'images/coins-item.png', accent: '#e8b65a', maxQuantite: 10,
      description: 'De quoi te faire plaisir dans la future boutique de cosmétiques en jeu.',
      avantages: ['1 000 Kamas cosmétiques', 'Utilisables pour les apparences', 'Aucun avantage compétitif'],
    },
    {
      id: 'kamas-3000', nom: '3 000 Kamas', categorie: 'Kamas', prix: 1299,
      image: 'images/coins-item.png', accent: '#e8b65a', badge: 'LE GRAND FORMAT', maxQuantite: 10,
      description: 'Encore plus de possibilités pour créer un style qui ne ressemble qu\'à toi.',
      avantages: ['3 000 Kamas cosmétiques', 'Utilisables pour les apparences', 'Aucun avantage compétitif'],
    },
    {
      id: 'pack-astral', nom: 'Pack Astral', categorie: 'Cosmétiques', prix: 799,
      image: 'images/chest-item.png', accent: '#b9a2f0', maxQuantite: 1,
      description: 'Une touche de magie pour accompagner chacun de tes pas.',
      avantages: ['Traînée de particules violettes', 'Apparence de coffre astral', 'Titre de profil Astral', 'Contenu fixe, sans tirage aléatoire'],
    },
  ] as ArticleBoutique[],
};

export const formatPrix = (centimes: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(centimes / 100);