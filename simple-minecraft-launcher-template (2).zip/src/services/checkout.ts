import { config } from '../config';
import type { CartLine } from '../state/ShopContext';

// A future backend must recalculate prices and fulfil purchases from verified webhooks.
// No card information or merchant secret is ever handled by the launcher.
export async function createCheckout(items: CartLine[], recipient: string): Promise<string> {
  if (!config.paiement.actif || !config.paiement.endpoint) throw new Error('Les paiements ne sont pas encore ouverts. Ton panier reste sauvegardé.');
  if (!/^https:\/\//.test(config.paiement.endpoint)) throw new Error('Le service de paiement doit utiliser HTTPS.');
  const response = await fetch(config.paiement.endpoint, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items: items.map(item => ({ productId: item.id, quantity: item.quantite })), recipient }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) throw new Error('Le service de paiement est indisponible. Aucun paiement effectué.');
  const data: { checkoutUrl?: string } = await response.json();
  if (!data.checkoutUrl) throw new Error('Réponse du service de paiement invalide.');
  const url = new URL(data.checkoutUrl);
  if (url.protocol !== 'https:' || !config.paiement.originesAutorisees.includes(url.origin)) throw new Error('Domaine de paiement non autorisé.');
  return url.href;
}