'use strict';

const { REST, Routes } = require('discord.js');
const { definitions } = require('./commands');

const { DISCORD_TOKEN, DISCORD_CLIENT_ID, GUILD_ID } = process.env;
if (!DISCORD_TOKEN || !DISCORD_CLIENT_ID) {
  console.error('DISCORD_TOKEN and DISCORD_CLIENT_ID are required.');
  process.exit(1);
}

const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
const route = GUILD_ID ? Routes.applicationGuildCommands(DISCORD_CLIENT_ID, GUILD_ID) : Routes.applicationCommands(DISCORD_CLIENT_ID);

rest
  .put(route, { body: definitions })
  .then((res) => console.log(`Registered ${res.length} command(s) ${GUILD_ID ? 'on server ' + GUILD_ID : 'globally'}.`))
  .catch((e) => {
    console.error('Command registration failed:', e.message);
    process.exit(1);
  });