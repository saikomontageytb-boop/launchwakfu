'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const store = require('./store');

const MAX_BODY = 4096;
const LIMIT_PER_MIN = 30;
const hits = new Map();

setInterval(() => {
  const cutoff = Date.now() - 60000;
  for (const [ip, list] of hits) {
    const fresh = list.filter((t) => t > cutoff);
    if (fresh.length) hits.set(ip, fresh);
    else hits.delete(ip);
  }
}, 60000).unref();

function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  list.push(now);
  hits.set(ip, list);
  return list.length > LIMIT_PER_MIN;
}

function sameSecret(given, expected) {
  const a = crypto.createHash('sha256').update(String(given || '')).digest();
  const b = crypto.createHash('sha256').update(expected).digest();
  return crypto.timingSafeEqual(a, b);
}

function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data), 'Cache-Control': 'no-store' });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new Error('too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

// onActivated({ plan, last4, user, activatedAt, expiresAt }) is called after a successful activation.
function start({ host, port, secret, onActivated }) {
  if (!secret || secret.length < 16) {
    console.warn('[api] API_SECRET missing or shorter than 16 characters: HTTP API disabled.');
    return null;
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');

      if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });

      if (req.method === 'POST' && url.pathname === '/activate') {
        if (limited(req.socket.remoteAddress || 'unknown')) return send(res, 429, { ok: false, reason: 'rate_limited' });
        if (!sameSecret(req.headers['x-api-secret'], secret)) return send(res, 401, { ok: false, reason: 'unauthorized' });

        let payload;
        try {
          payload = JSON.parse(await readBody(req));
        } catch {
          return send(res, 400, { ok: false, reason: 'bad_request' });
        }
        const key = typeof payload.key === 'string' ? payload.key.trim() : '';
        const user = typeof payload.user === 'string' ? payload.user.trim().slice(0, 60) : '';
        if (key.length < 8 || key.length > 64) return send(res, 400, { ok: false, reason: 'bad_request' });

        const result = store.activateKey(key, user);
        if (!result.ok) {
          const status = { invalid: 404, used: 409, revoked: 410 }[result.reason] || 400;
          return send(res, status, { ok: false, reason: result.reason });
        }

        const rec = result.rec;
        send(res, 200, { ok: true, plan: rec.plan, expiresAt: rec.expiresAt });
        Promise.resolve()
          .then(() => onActivated({ plan: rec.plan, last4: rec.last4, user, activatedAt: rec.activatedAt, expiresAt: rec.expiresAt }))
          .catch((e) => console.error('[api] onActivated failed:', e.message));
        return undefined;
      }

      return send(res, 404, { ok: false, reason: 'not_found' });
    } catch (e) {
      console.error('[api] error:', e.message);
      if (!res.headersSent) return send(res, 500, { ok: false, reason: 'server_error' });
      return undefined;
    }
  });

  server.listen(port, host, () => console.log(`[api] listening on ${host}:${port}`));
  return server;
}

module.exports = { start };