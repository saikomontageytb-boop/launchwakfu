'use strict';

const crypto = require('node:crypto');
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  SlashCommandBuilder
} = require('discord.js');
const { tr, NAMES, LANGS } = require('./i18n');
const store = require('./store');
const tickets = require('./tickets');

const COLOR = 0xef6f4e;
const EPHEMERAL = MessageFlags.Ephemeral;
const OWNERS = (process.env.OWNER_IDS || '').split(',').map((s) => s.trim()).filter(Boolean);
const SITE_URL = (process.env.SITE_URL || 'https://unlimitedclaud.com').replace(/\/+$/, '');
const ADMIN_SECRET = process.env.ADMIN_SECRET || '';

// Calls the Cloudflare Pages Function /api/admin (keys live in Cloudflare KV, not on this machine).
async function siteAdmin(body) {
  if (!ADMIN_SECRET) throw new Error('ADMIN_SECRET is missing');
  const res = await fetch(SITE_URL + '/api/admin', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-admin-secret': ADMIN_SECRET },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(10000)
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}
// An auto-role must never hand out moderation powers to every newcomer.
const DANGEROUS_PERMISSIONS = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageRoles,
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.BanMembers,
  PermissionFlagsBits.KickMembers
];

// subcommand -> [guild field, channel type, description]
const CHANNEL_SETTINGS = {
  'welcome-channel': ['welcomeChannel', ChannelType.GuildText, 'Channel for welcome messages (leave empty to disable)'],
  'join-log': ['joinLogChannel', ChannelType.GuildText, 'Channel where member origins are logged (leave empty to disable)'],
  'key-log': ['keyLogChannel', ChannelType.GuildText, 'Channel where key activations are logged (leave empty to disable)'],
  'ticket-category': ['ticketParent', ChannelType.GuildCategory, 'Category where ticket channels are created'],
  'ticket-log': ['ticketLogChannel', ChannelType.GuildText, 'Channel where closed tickets are logged (leave empty to disable)']
};

function buildConfig() {
  const cmd = new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configure the bot for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addSubcommand((s) => s.setName('show').setDescription('Show the current settings'))
    .addSubcommand((s) =>
      s
        .setName('language')
        .setDescription('Set the bot language for this server')
        .addStringOption((o) =>
          o.setName('language').setDescription('Language').setRequired(true).addChoices(...LANGS.map((l) => ({ name: NAMES[l], value: l })))
        )
    )
    .addSubcommand((s) =>
      s.setName('staff-role').setDescription('Role allowed to handle tickets (leave empty to clear)').addRoleOption((o) => o.setName('role').setDescription('Staff role'))
    )
    .addSubcommand((s) =>
      s.setName('auto-role').setDescription('Role given automatically to new members (leave empty to disable)').addRoleOption((o) => o.setName('role').setDescription('Role to give on join'))
    );
  for (const [name, [, type, description]] of Object.entries(CHANNEL_SETTINGS)) {
    cmd.addSubcommand((s) => s.setName(name).setDescription(description).addChannelOption((o) => o.setName('channel').setDescription('Channel').addChannelTypes(type)));
  }
  return cmd;
}

function buildTicket() {
  return new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('panel')
        .setDescription('Send the ticket panel')
        .addChannelOption((o) => o.setName('channel').setDescription('Where to send it (default: here)').addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((s) =>
      s
        .setName('category-add')
        .setDescription('Add a ticket category to the selection menu')
        .addStringOption((o) => o.setName('label').setDescription('Name shown in the menu').setRequired(true).setMaxLength(50))
        .addStringOption((o) => o.setName('description').setDescription('Short description shown under the name').setMaxLength(100))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji shown next to the name').setMaxLength(60))
        .addStringOption((o) => o.setName('message').setDescription('Message posted at the top of tickets of this category').setMaxLength(500))
        .addRoleOption((o) => o.setName('role').setDescription('Extra role that can see and is pinged in these tickets'))
    )
    .addSubcommand((s) =>
      s
        .setName('category-remove')
        .setDescription('Remove a ticket category')
        .addStringOption((o) => o.setName('category').setDescription('Category').setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) => s.setName('category-list').setDescription('List ticket categories'));
}

function buildKey() {
  return new SlashCommandBuilder()
    .setName('key')
    .setDescription('Manage activation keys (bot owners only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Create a key')
        .addStringOption((o) =>
          o
            .setName('plan')
            .setDescription('Plan of the key')
            .setRequired(true)
            .addChoices({ name: 'Pro', value: 'Pro' }, { name: 'Pro+', value: 'Pro+' })
        )
        .addIntegerOption((o) => o.setName('days').setDescription('Duration in days after activation (0 = lifetime, default 30)').setMinValue(0).setMaxValue(3650))
        .addUserOption((o) => o.setName('user').setDescription('Member who receives the key by DM (adds a "Send by DM" button)'))
    )
    .addSubcommand((s) => s.setName('revoke').setDescription('Revoke a key').addStringOption((o) => o.setName('key').setDescription('The full key').setRequired(true).setMaxLength(64)))
    .addSubcommand((s) => s.setName('list').setDescription('Show the latest keys'))
    .addSubcommand((s) => s.setName('usage').setDescription('Dashboard: usage of every key and who received it'))
    .addSubcommand((s) =>
      s
        .setName('logs')
        .setDescription('Usage logs of the keys')
        .addStringOption((o) => o.setName('key').setDescription('Last 4 characters of a key (empty = latest logs of all keys)').setMaxLength(32))
    );
}

const definitions = [buildConfig(), buildTicket(), buildKey()].map((c) => c.toJSON());

function reply(i, content) {
  return i.reply({ content, flags: EPHEMERAL, allowedMentions: { parse: [] } });
}

async function runConfig(i, g) {
  const T = (k, v) => tr(g.lang, k, v);
  const sub = i.options.getSubcommand();

  if (sub === 'show') {
    const mention = (id, prefix) => (id ? `${prefix}${id}>` : T('cfg.unset'));
    const embed = new EmbedBuilder()
      .setColor(COLOR)
      .setTitle(T('cfg.show'))
      .setDescription(
        [
          `Language: **${NAMES[g.lang] || g.lang}**`,
          `welcome-channel: ${mention(g.welcomeChannel, '<#')}`,
          `join-log: ${mention(g.joinLogChannel, '<#')}`,
          `key-log: ${mention(g.keyLogChannel, '<#')}`,
          `ticket-category: ${mention(g.ticketParent, '<#')}`,
          `ticket-log: ${mention(g.ticketLogChannel, '<#')}`,
          `staff-role: ${mention(g.staffRole, '<@&')}`,
          `auto-role: ${mention(g.autoRole, '<@&')}`,
          `ticket categories: **${g.ticketCats.length}**`
        ].join('\n')
      );
    return i.reply({ embeds: [embed], flags: EPHEMERAL });
  }

  if (sub === 'language') {
    g.lang = i.options.getString('language', true);
    store.save();
    return reply(i, tr(g.lang, 'cfg.saved'));
  }

  if (sub === 'staff-role') {
    const role = i.options.getRole('role');
    g.staffRole = role ? role.id : null;
    store.save();
    return reply(i, T('cfg.saved'));
  }

  if (sub === 'auto-role') {
    const picked = i.options.getRole('role');
    if (!picked) {
      g.autoRole = null;
      store.save();
      return reply(i, T('cfg.autoRoleCleared'));
    }
    const role = await i.guild.roles.fetch(picked.id).catch(() => null);
    if (!role || role.id === i.guildId || role.managed) return reply(i, T('cfg.autoRoleInvalid'));
    if (role.permissions.any(DANGEROUS_PERMISSIONS)) return reply(i, T('cfg.autoRoleDanger'));
    const me = i.guild.members.me;
    if (!me || !me.permissions.has(PermissionFlagsBits.ManageRoles)) return reply(i, T('cfg.autoRoleNoPerm'));
    if (role.comparePositionTo(me.roles.highest) >= 0) return reply(i, T('cfg.autoRoleHigh'));
    g.autoRole = role.id;
    store.save();
    return reply(i, T('cfg.autoRoleSet', { role: `<@&${role.id}>` }));
  }

  const setting = CHANNEL_SETTINGS[sub];
  if (setting) {
    const channel = i.options.getChannel('channel');

    if (sub === 'key-log') {
      // The activation notice is posted by the Cloudflare Pages Function, so the site needs a webhook for the channel.
      if (!OWNERS.includes(i.user.id)) return reply(i, T('err.owner'));
      await i.deferReply({ flags: EPHEMERAL });
      try {
        let url = '';
        if (channel) {
          const target = await i.guild.channels.fetch(channel.id);
          const hook = await target.createWebhook({ name: 'Unlimited Claud', reason: 'Key activation logs' });
          url = hook.url;
        }
        const { status, data } = await siteAdmin({ action: 'webhook', url, lang: g.lang });
        if (status !== 200 || !data.ok) throw new Error('webhook failed: ' + status + ' ' + (data.error || ''));
      } catch (e) {
        console.error('[key-log] could not register the webhook on the site:', e.message);
        return i.editReply({ content: T('err.generic') });
      }
      g.keyLogChannel = channel ? channel.id : null;
      store.save();
      return i.editReply({ content: T('cfg.saved') });
    }

    g[setting[0]] = channel ? channel.id : null;
    store.save();
    return reply(i, T('cfg.saved'));
  }
  return reply(i, T('err.generic'));
}

async function runTicket(i, g) {
  const T = (k, v) => tr(g.lang, k, v);
  const sub = i.options.getSubcommand();

  if (sub === 'panel') {
    if (!g.ticketCats.length) return reply(i, T('ticket.noCats'));
    if (!g.ticketParent) return reply(i, T('ticket.notSetup'));
    const picked = i.options.getChannel('channel');
    const channel = picked ? await i.guild.channels.fetch(picked.id) : i.channel;
    await tickets.sendPanel(channel, g);
    return reply(i, T('ticket.panelSent'));
  }

  if (sub === 'category-add') {
    if (g.ticketCats.length >= 25) return reply(i, T('ticket.catLimit'));
    const emoji = (i.options.getString('emoji') || '').trim();
    if (emoji && !tickets.EMOJI_RE.test(emoji)) return reply(i, T('ticket.badEmoji'));
    const role = i.options.getRole('role');
    const cat = {
      id: crypto.randomBytes(4).toString('hex'),
      label: i.options.getString('label', true).trim(),
      description: (i.options.getString('description') || '').trim(),
      emoji,
      message: (i.options.getString('message') || '').trim(),
      roleId: role ? role.id : null
    };
    g.ticketCats.push(cat);
    store.save();
    return reply(i, T('ticket.catAdded', { label: cat.label }));
  }

  if (sub === 'category-remove') {
    const id = i.options.getString('category', true);
    const before = g.ticketCats.length;
    g.ticketCats = g.ticketCats.filter((c) => c.id !== id);
    if (g.ticketCats.length === before) return reply(i, T('ticket.catUnknown'));
    store.save();
    return reply(i, T('ticket.catRemoved'));
  }

  if (sub === 'category-list') {
    const lines = g.ticketCats.map((c) => `${c.emoji ? c.emoji + ' ' : ''}**${c.label}**${c.description ? ' — ' + c.description : ''}`);
    const embed = new EmbedBuilder().setColor(COLOR).setTitle(T('ticket.catList')).setDescription(lines.join('\n') || T('ticket.catNone'));
    return i.reply({ embeds: [embed], flags: EPHEMERAL, allowedMentions: { parse: [] } });
  }
  return reply(i, T('err.generic'));
}

async function runKey(i, g) {
  const T = (k, v) => tr(g.lang, k, v);
  if (!OWNERS.includes(i.user.id)) return reply(i, T('err.owner'));
  const sub = i.options.getSubcommand();
  await i.deferReply({ flags: EPHEMERAL });

  try {
    if (sub === 'create') {
      const plan = i.options.getString('plan', true).trim();
      const days = i.options.getInteger('days') ?? 30;
      const target = i.options.getUser('user');
      if (target && target.bot) return await i.editReply({ content: T('key.dmBot') });
      const request = { action: 'create', plan, days };
      if (target) {
        request.ownerId = target.id;
        request.ownerTag = target.username;
      }
      const { status, data } = await siteAdmin(request);
      if (status !== 200 || !data.ok) throw new Error('create failed: ' + status + ' ' + (data.error || ''));
      const payload = { content: T('key.created', { key: data.key, plan: data.plan, days: data.days }) };
      if (target) {
        payload.content += '\n' + T('key.dmTarget', { user: esc(target.username) });
        payload.components = [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`keydm:${target.id}:${data.key}`).setLabel(T('key.dmButton')).setStyle(ButtonStyle.Primary)
          )
        ];
      }
      return await i.editReply(payload);
    }

    if (sub === 'revoke') {
      const { status, data } = await siteAdmin({ action: 'revoke', key: i.options.getString('key', true) });
      if (status === 404) return await i.editReply({ content: T('key.notFound') });
      if (status !== 200 || !data.ok) throw new Error('revoke failed: ' + status + ' ' + (data.error || ''));
      return await i.editReply({ content: T('key.revoked') });
    }

    if (sub === 'list') {
      const { status, data } = await siteAdmin({ action: 'list', limit: 15 });
      if (status !== 200 || !data.ok) throw new Error('list failed: ' + status + ' ' + (data.error || ''));
      const lines = (data.keys || []).map((k) => `\`…${k.last4}\` · ${k.plan} · ${k.days}d · ${T('key.status.' + k.status)}`);
      const embed = new EmbedBuilder().setColor(COLOR).setTitle(T('key.listTitle')).setDescription(lines.join('\n') || T('key.listNone'));
      return await i.editReply({ embeds: [embed] });
    }

    if (sub === 'usage') {
      const { status, data } = await siteAdmin({ action: 'usage', limit: 15 });
      if (status !== 200 || !data.ok) throw new Error('usage failed: ' + status + ' ' + (data.error || ''));
      const lines = (data.keys || []).map((k) => {
        const owner = k.ownerTag ? esc(k.ownerTag) : '-';
        const last = k.lastAt ? `<t:${Math.floor(k.lastAt / 1000)}:R>` : '-';
        return (
          `\`…${k.last4}\` · **${owner}** · ${k.plan} · ${T('key.status.' + k.status)}\n` +
          T('key.usageLine', { tokens: k.tokensToday, requests: k.requestsToday, total: k.totalRequests, last })
        );
      });
      const tot = data.totals || {};
      const embed = new EmbedBuilder()
        .setColor(COLOR)
        .setTitle(T('key.usageTitle'))
        .setDescription(lines.join('\n\n').slice(0, 4000) || T('key.usageNone'))
        .addFields(
          { name: T('key.usageKeys'), value: String(tot.keys || 0), inline: true },
          { name: T('key.usageToday'), value: T('key.usageTodayVal', { requests: tot.requestsToday || 0, tokens: tot.tokensToday || 0 }), inline: true },
          { name: T('key.usageCap'), value: String(data.cap || '-'), inline: true }
        );
      return await i.editReply({ embeds: [embed] });
    }

    if (sub === 'logs') {
      const given = i.options.getString('key') || '';
      const clean = given.replace(/[^A-Za-z0-9]/g, '');
      if (given && clean.length < 4) return await i.editReply({ content: T('key.notFound') });
      const request = { action: 'logs', limit: 20 };
      if (clean) request.last4 = clean.slice(-4).toUpperCase();
      const { status, data } = await siteAdmin(request);
      if (status === 404) return await i.editReply({ content: T('key.notFound') });
      if (status !== 200 || !data.ok) throw new Error('logs failed: ' + status + ' ' + (data.error || ''));
      const lines = (data.entries || []).map((e) => {
        const what = e.blocked ? T('key.logBlocked') : T('key.logTokens', { model: e.model || '-', tokens: e.tokens });
        const owner = e.ownerTag ? esc(e.ownerTag) : '-';
        return `<t:${Math.floor(e.at / 1000)}:f> · \`…${e.last4}\` · **${owner}** · ${what}`;
      });
      const embed = new EmbedBuilder()
        .setColor(COLOR)
        .setTitle(T('key.logsTitle'))
        .setDescription(lines.join('\n').slice(0, 4000) || T('key.logsNone'));
      return await i.editReply({ embeds: [embed] });
    }
  } catch (e) {
    console.error('[key] site admin call failed:', e.message);
    return i.editReply({ content: T('err.generic') });
  }
  return i.editReply({ content: T('err.generic') });
}

// Escapes Discord markdown in text that comes from usernames.
function esc(text) {
  return String(text).replace(/([\\*_~`|>])/g, '\\$1');
}

// English DM sent to the member who receives a key.
function keyDmEmbed(key) {
  const link = `${SITE_URL}/app.html#activate=${key}`;
  return new EmbedBuilder()
    .setColor(COLOR)
    .setTitle('Your Unlimited Claud access key')
    .setDescription(
      [
        'Here is your personal activation key:',
        '',
        '`' + key + '`',
        '',
        '**[Click here to activate your key](' + link + ')**',
        '',
        '1. Open the link and sign in to your account.',
        '2. Press the activation button on the page.',
        '',
        'Keep this key private. It can only be activated once.'
      ].join('\n')
    )
    .setFooter({ text: 'Unlimited Claud' });
}

const KEY_BUTTON_RE = /^keydm:(\d{15,25}):(UC(?:-[A-Z0-9]{4}){4})$/;

// "Send by DM" button shown under /key create.
async function onKeyButton(i) {
  const g = i.inGuild() ? store.guild(i.guildId) : { lang: 'en' };
  const T = (k, v) => tr(g.lang, k, v);
  if (!OWNERS.includes(i.user.id)) return reply(i, T('err.owner'));
  const match = KEY_BUTTON_RE.exec(i.customId);
  if (!match) return reply(i, T('err.generic'));
  await i.deferUpdate();

  const [, userId, key] = match;
  let target = null;
  try {
    target = await i.client.users.fetch(userId);
    await target.send({ embeds: [keyDmEmbed(key)], allowedMentions: { parse: [] } });
  } catch (e) {
    console.error('[key] DM failed:', e.message);
    return i.followUp({ content: T('key.dmFailed', { user: esc(target ? target.username : userId) }), flags: EPHEMERAL });
  }
  return i.editReply({ content: `${i.message.content}\n${T('key.dmSent', { user: esc(target.username) })}`, components: [] });
}

async function execute(i) {
  if (!i.inGuild()) return undefined;
  const g = store.guild(i.guildId);
  switch (i.commandName) {
    case 'config':
      if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return reply(i, tr(g.lang, 'err.perm'));
      return runConfig(i, g);
    case 'ticket':
      if (!i.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return reply(i, tr(g.lang, 'err.perm'));
      return runTicket(i, g);
    case 'key':
      return runKey(i, g);
    default:
      return undefined;
  }
}

async function autocomplete(i) {
  if (!i.inGuild() || i.commandName !== 'ticket') return i.respond([]);
  const g = store.guild(i.guildId);
  const q = String(i.options.getFocused()).toLowerCase();
  const choices = g.ticketCats
    .filter((c) => c.label.toLowerCase().includes(q))
    .slice(0, 25)
    .map((c) => ({ name: c.label.slice(0, 100), value: c.id }));
  return i.respond(choices);
}

module.exports = { definitions, execute, autocomplete, onKeyButton };