'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, '..', 'data');
const FILE = path.join(DIR, 'db.json');

const DAY = 86400000;

function defaultGuild() {
  return {
    lang: 'en',
    welcomeChannel: null,
    joinLogChannel: null,
    keyLogChannel: null,
    ticketParent: null,
    ticketLogChannel: null,
    staffRole: null,
    autoRole: null,
    ticketCats: [],
    tickets: {}
  };
}

let db = { guilds: {}, keys: {} };

function load() {
  fs.mkdirSync(DIR, { recursive: true });
  try {
    const parsed = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    db = { guilds: parsed.guilds || {}, keys: parsed.keys || {} };
  } catch (e) {
    // A missing file is a fresh start. A corrupted file must NOT be overwritten silently.
    if (e.code !== 'ENOENT') throw new Error('Cannot read ' + FILE + ': ' + e.message);
  }
}

function save() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, FILE);
}

function guild(id) {
  if (!db.guilds[id]) db.guilds[id] = defaultGuild();
  const g = Object.assign(defaultGuild(), db.guilds[id]);
  db.guilds[id] = g;
  return g;
}

function hashKey(plain) {
  return crypto.createHash('sha256').update(String(plain).trim().toUpperCase()).digest('hex');
}

function newKeyString() {
  // Crockford-like alphabet without ambiguous characters.
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(16);
  let out = '';
  for (let i = 0; i < 16; i++) {
    out += alphabet[bytes[i] % alphabet.length];
    if (i % 4 === 3 && i < 15) out += '-';
  }
  return 'UC-' + out;
}

function createKey(plan, days, createdBy) {
  const plain = newKeyString();
  db.keys[hashKey(plain)] = {
    plan: String(plan).slice(0, 20),
    days: Math.max(0, Math.floor(days)),
    createdAt: Date.now(),
    createdBy: createdBy || null,
    activatedAt: null,
    activatedBy: null,
    expiresAt: null,
    revoked: false,
    last4: plain.slice(-4)
  };
  save();
  return plain;
}

function findKey(plain) {
  const h = hashKey(plain);
  return db.keys[h] ? { hash: h, rec: db.keys[h] } : null;
}

// Returns { ok: true, rec } or { ok: false, reason: 'invalid' | 'used' | 'revoked' }
function activateKey(plain, label) {
  const found = findKey(plain);
  if (!found) return { ok: false, reason: 'invalid' };
  const rec = found.rec;
  if (rec.revoked) return { ok: false, reason: 'revoked' };
  if (rec.activatedAt) return { ok: false, reason: 'used' };
  rec.activatedAt = Date.now();
  rec.activatedBy = String(label || '').slice(0, 60) || null;
  rec.expiresAt = rec.days > 0 ? rec.activatedAt + rec.days * DAY : null;
  save();
  return { ok: true, rec };
}

function revokeKey(plain) {
  const found = findKey(plain);
  if (!found) return false;
  found.rec.revoked = true;
  save();
  return true;
}

function listKeys(limit) {
  return Object.values(db.keys)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, limit || 10);
}

module.exports = { load, save, guild, createKey, activateKey, revokeKey, listKeys, defaultGuild };