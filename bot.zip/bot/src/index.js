'use strict';

const { Client, EmbedBuilder, Events, GatewayIntentBits, MessageFlags, PermissionFlagsBits } = require('discord.js');
const store = require('./store');
const { tr, LOCALES } = require('./i18n');
const invites = require('./invites');
const tickets = require('./tickets');
const commands = require('./commands');
const api = require('./api');

const COLOR = 0xef6f4e;

if (!process.env.DISCORD_TOKEN) {
  console.error('DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const intents = [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildInvites];
if (process.env.MESSAGE_CONTENT === 'true') intents.push(GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent);

const client = new Client({ intents });
store.load();

async function textChannel(guild, id) {
  if (!id) return null;
  const ch = await guild.channels.fetch(id).catch(() => null);
  return ch && ch.isTextBased() ? ch : null;
}

function unixTs(ms) {
  return Math.floor(ms / 1000);
}

async function giveAutoRole(member, roleId) {
  const role = await member.guild.roles.fetch(roleId).catch(() => null);
  if (!role) return console.error('[autorole] role not found in', member.guild.id);
  const me = member.guild.members.me;
  if (!me || !me.permissions.has(PermissionFlagsBits.ManageRoles)) return console.error('[autorole] missing Manage Roles in', member.guild.id);
  if (role.managed || role.comparePositionTo(me.roles.highest) >= 0) return console.error('[autorole] role is above the bot in', member.guild.id);
  return member.roles.add(role, 'Auto-role').catch((e) => console.error('[autorole] add failed:', e.message));
}

async function onMemberAdd(member) {
  const g = store.guild(member.guild.id);
  const lang = g.lang;
  const origin = await invites.detect(member).catch((e) => {
    console.error('[invites] detect failed:', e.message);
    return { type: 'unknown' };
  });

  if (g.autoRole) await giveAutoRole(member, g.autoRole);

  let via;
  if (origin.type === 'invite') via = origin.inviterId ? `<@${origin.inviterId}> (\`${origin.code}\`)` : `\`${origin.code}\``;
  else if (origin.type === 'vanity') via = `${tr(lang, 'join.vanity')} (\`${origin.code}\`)`;
  else if (origin.type === 'bot') via = tr(lang, 'join.bot');
  else via = tr(lang, 'join.unknown');

  const welcome = await textChannel(member.guild, g.welcomeChannel);
  if (welcome) {
    const embed = new EmbedBuilder()
      .setColor(COLOR)
      .setTitle(tr(lang, 'welcome.title', { user: member.displayName }))
      .setDescription(tr(lang, 'welcome.desc', { count: member.guild.memberCount, guild: member.guild.name }))
      .setThumbnail(member.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: tr(lang, 'welcome.created'), value: `<t:${unixTs(member.user.createdTimestamp)}:R>`, inline: true },
        { name: tr(lang, 'welcome.via'), value: via, inline: true }
      )
      .setTimestamp();
    await welcome
      .send({ content: `<@${member.id}>`, embeds: [embed], allowedMentions: { users: [member.id] } })
      .catch((e) => console.error('[welcome] send failed:', e.message));
  }

  const log = await textChannel(member.guild, g.joinLogChannel);
  if (log) {
    const fields = [
      { name: 'Member', value: `<@${member.id}>\n\`${member.id}\``, inline: true },
      { name: tr(lang, 'welcome.created'), value: `<t:${unixTs(member.user.createdTimestamp)}:R>`, inline: true }
    ];
    if (origin.type === 'invite') {
      fields.push({ name: tr(lang, 'join.inviter'), value: origin.inviterId ? `<@${origin.inviterId}>` : '-', inline: true });
      fields.push({ name: tr(lang, 'join.code'), value: `\`${origin.code}\``, inline: true });
      fields.push({ name: tr(lang, 'join.uses'), value: String(origin.uses), inline: true });
    } else {
      fields.push({ name: tr(lang, 'welcome.via'), value: via, inline: false });
    }
    const embed = new EmbedBuilder()
      .setColor(COLOR)
      .setTitle(tr(lang, 'join.title'))
      .setThumbnail(member.displayAvatarURL({ size: 128 }))
      .addFields(fields)
      .setTimestamp();
    await log.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch((e) => console.error('[joinlog] send failed:', e.message));
  }
}

async function onKeyActivated(info) {
  for (const guild of client.guilds.cache.values()) {
    const g = store.guild(guild.id);
    if (!g.keyLogChannel) continue;
    const ch = await textChannel(guild, g.keyLogChannel);
    if (!ch) continue;
    const lang = g.lang;
    const embed = new EmbedBuilder()
      .setColor(COLOR)
      .setTitle(tr(lang, 'key.title'))
      .addFields(
        { name: tr(lang, 'key.key'), value: `\`UC-••••-••••-••••-${info.last4}\``, inline: false },
        { name: tr(lang, 'key.plan'), value: info.plan, inline: true },
        { name: tr(lang, 'key.user'), value: info.user || '-', inline: true },
        { name: tr(lang, 'key.expires'), value: info.expiresAt ? `<t:${unixTs(info.expiresAt)}:F>` : tr(lang, 'key.never'), inline: true },
        { name: tr(lang, 'key.at'), value: `<t:${unixTs(info.activatedAt)}:F>`, inline: true }
      )
      .setTimestamp(info.activatedAt);
    await ch.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch((e) => console.error('[keylog] send failed:', e.message));
  }
}

async function fail(i, e) {
  console.error('[interaction] error:', e);
  const lang = i.guildId ? store.guild(i.guildId).lang : 'en';
  const msg = { content: tr(lang, 'err.generic'), flags: MessageFlags.Ephemeral };
  try {
    if (i.replied || i.deferred) await i.followUp(msg);
    else if (i.isRepliable()) await i.reply(msg);
  } catch {
    /* interaction expired */
  }
}

client.once(Events.ClientReady, async (c) => {
  console.log(`[bot] logged in as ${c.user.tag} on ${c.guilds.cache.size} server(s)`);
  c.user.setActivity('Unlimited Claud');
  for (const guild of c.guilds.cache.values()) await invites.prime(guild);
});

client.on(Events.GuildCreate, (guild) => invites.prime(guild));
client.on(Events.InviteCreate, (invite) => invites.onCreate(invite));
client.on(Events.GuildMemberAdd, (member) => onMemberAdd(member).catch((e) => console.error('[member] error:', e)));

client.on(Events.InteractionCreate, async (i) => {
  try {
    if (i.isChatInputCommand()) return await commands.execute(i);
    if (i.isAutocomplete()) return await commands.autocomplete(i);
    if (i.isStringSelectMenu() && i.customId === 'ticket:select') return await tickets.onSelect(i);
    if (i.isModalSubmit() && i.customId.startsWith('ticket:modal:')) return await tickets.onModal(i);
    if (i.isButton() && i.customId.startsWith('keydm:')) return await commands.onKeyButton(i);
    if (i.isButton() && i.customId.startsWith('ticket:')) return await tickets.onButton(i);
  } catch (e) {
    await fail(i, e);
  }
  return undefined;
});

client.on(Events.Error, (e) => console.error('[client] error:', e));
process.on('unhandledRejection', (e) => console.error('[process] unhandledRejection:', e));

const server = api.start({
  host: process.env.API_HOST || '127.0.0.1',
  port: Number(process.env.API_PORT) || 8090,
  secret: process.env.API_SECRET || '',
  onActivated: onKeyActivated
});

function shutdown() {
  console.log('[bot] shutting down');
  if (server) server.close();
  client.destroy();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

client.login(process.env.DISCORD_TOKEN);

module.exports = { LOCALES };