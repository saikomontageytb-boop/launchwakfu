'use strict';

const {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { tr } = require('./i18n');
const store = require('./store');

const COLOR = 0xef6f4e;
const EPHEMERAL = MessageFlags.Ephemeral;

// Standard emoji or custom emoji markup such as <:name:123456789012345678>
const EMOJI_RE = /^(<a?:\w{2,32}:\d{17,20}>|\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)$/u;

const closing = new Set();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function parseEmoji(s) {
  if (!s) return undefined;
  const m = /^<(a?):(\w{2,32}):(\d{17,20})>$/.exec(s);
  if (m) return { animated: m[1] === 'a', name: m[2], id: m[3] };
  return { name: s };
}

function isStaff(member, g) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.ManageChannels)) return true;
  return Boolean(g.staffRole) && member.roles.cache.has(g.staffRole);
}

function panelRow(g) {
  const options = g.ticketCats.slice(0, 25).map((c) => {
    const o = { label: c.label, value: c.id };
    if (c.description) o.description = c.description;
    const emoji = parseEmoji(c.emoji);
    if (emoji) o.emoji = emoji;
    return o;
  });
  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket:select')
    .setPlaceholder(tr(g.lang, 'ticket.placeholder'))
    .addOptions(options);
  return new ActionRowBuilder().addComponents(menu);
}

function ticketButtons(lang, claimed) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket:claim').setLabel(tr(lang, 'ticket.claim')).setStyle(ButtonStyle.Primary).setDisabled(Boolean(claimed)),
    new ButtonBuilder().setCustomId('ticket:close').setLabel(tr(lang, 'ticket.close')).setStyle(ButtonStyle.Danger)
  );
}

async function sendPanel(channel, g) {
  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(tr(g.lang, 'ticket.panelTitle'))
    .setDescription(tr(g.lang, 'ticket.panelDesc'));
  return channel.send({ embeds: [embed], components: [panelRow(g)] });
}

function findOpenTicket(guild, g, userId) {
  let changed = false;
  let found = null;
  for (const [channelId, rec] of Object.entries(g.tickets)) {
    if (!guild.channels.cache.has(channelId)) {
      delete g.tickets[channelId]; // channel was deleted by hand
      changed = true;
      continue;
    }
    if (rec.userId === userId) found = channelId;
  }
  if (changed) store.save();
  return found;
}

async function onSelect(i) {
  const g = store.guild(i.guildId);
  const lang = g.lang;
  const cat = g.ticketCats.find((c) => c.id === i.values[0]);
  if (!cat) {
    await i.reply({ content: tr(lang, 'ticket.catUnknown'), flags: EPHEMERAL });
    i.message.edit({ components: [panelRow(g)] }).catch(() => {});
    return;
  }
  const existing = findOpenTicket(i.guild, g, i.user.id);
  if (existing) {
    await i.reply({ content: tr(lang, 'ticket.already', { channel: `<#${existing}>` }), flags: EPHEMERAL });
    i.message.edit({ components: [panelRow(g)] }).catch(() => {});
    return;
  }

  const modal = new ModalBuilder()
    .setCustomId('ticket:modal:' + cat.id)
    .setTitle(tr(lang, 'ticket.modalTitle').slice(0, 45))
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('subject').setLabel(tr(lang, 'ticket.subject').slice(0, 45)).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('details').setLabel(tr(lang, 'ticket.details').slice(0, 45)).setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000)
      )
    );
  await i.showModal(modal);
  // Reset the select menu so the same category can be picked again later.
  i.message.edit({ components: [panelRow(g)] }).catch(() => {});
}

async function onModal(i) {
  const g = store.guild(i.guildId);
  const lang = g.lang;
  await i.deferReply({ flags: EPHEMERAL });

  const cat = g.ticketCats.find((c) => c.id === i.customId.slice('ticket:modal:'.length));
  if (!cat) return i.editReply(tr(lang, 'ticket.catUnknown'));

  const parent = g.ticketParent ? i.guild.channels.cache.get(g.ticketParent) : null;
  if (!parent || parent.type !== ChannelType.GuildCategory) return i.editReply(tr(lang, 'ticket.notSetup'));

  const existing = findOpenTicket(i.guild, g, i.user.id);
  if (existing) return i.editReply(tr(lang, 'ticket.already', { channel: `<#${existing}>` }));

  const subject = i.fields.getTextInputValue('subject').trim();
  const details = i.fields.getTextInputValue('details').trim();

  const view = [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles];
  const overwrites = [
    { id: i.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: i.user.id, allow: view },
    { id: i.guild.members.me.id, allow: [...view, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.EmbedLinks] }
  ];
  const roleIds = new Set([g.staffRole, cat.roleId].filter(Boolean));
  for (const id of roleIds) {
    if (i.guild.roles.cache.has(id)) overwrites.push({ id, allow: view });
  }

  const safe = i.user.username.toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 40);
  let channel;
  try {
    channel = await i.guild.channels.create({
      name: 'ticket-' + (safe || i.user.id.slice(-4)),
      type: ChannelType.GuildText,
      parent: parent.id,
      topic: `${cat.label} | ${i.user.id}`,
      permissionOverwrites: overwrites,
      reason: `Ticket opened by ${i.user.tag}`
    });
  } catch (e) {
    console.error('[tickets] channel create failed:', e.message);
    return i.editReply(tr(lang, 'err.generic'));
  }

  g.tickets[channel.id] = { userId: i.user.id, catId: cat.id, catLabel: cat.label, createdAt: Date.now(), claimedBy: null };
  store.save();

  const embed = new EmbedBuilder()
    .setColor(COLOR)
    .setTitle(subject)
    .setDescription(details)
    .addFields({ name: tr(lang, 'ticket.category'), value: cat.label.slice(0, 1024), inline: true })
    .setFooter({ text: i.user.tag })
    .setTimestamp();
  const intro = tr(lang, 'ticket.hello', { user: `<@${i.user.id}>` }) + (cat.message ? '\n\n' + cat.message : '');
  const mentionRoles = [...roleIds].filter((id) => i.guild.roles.cache.has(id));
  await channel.send({
    content: intro + (mentionRoles.length ? '\n' + mentionRoles.map((r) => `<@&${r}>`).join(' ') : ''),
    embeds: [embed],
    components: [ticketButtons(lang, false)],
    allowedMentions: { users: [i.user.id], roles: mentionRoles }
  });

  return i.editReply(tr(lang, 'ticket.created', { channel: `<#${channel.id}>` }));
}

async function buildTranscript(channel) {
  const all = [];
  let before;
  for (let page = 0; page < 5; page++) {
    const batch = await channel.messages.fetch({ limit: 100, before });
    if (!batch.size) break;
    all.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  all.reverse();
  return all
    .map((m) => {
      const files = m.attachments.size ? ' ' + [...m.attachments.values()].map((a) => a.url).join(' ') : '';
      return `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content}${files}`;
    })
    .join('\n');
}

async function onButton(i) {
  const g = store.guild(i.guildId);
  const lang = g.lang;
  const rec = g.tickets[i.channelId];
  if (!rec) return i.reply({ content: tr(lang, 'err.generic'), flags: EPHEMERAL });
  const staff = isStaff(i.member, g);

  if (i.customId === 'ticket:claim') {
    if (!staff) return i.reply({ content: tr(lang, 'ticket.staffOnly'), flags: EPHEMERAL });
    rec.claimedBy = i.user.id;
    store.save();
    await i.update({ components: [ticketButtons(lang, true)] });
    await i.channel.send({ content: tr(lang, 'ticket.claimedBy', { user: `<@${i.user.id}>` }), allowedMentions: { parse: [] } });
    return undefined;
  }

  if (i.customId === 'ticket:close') {
    if (!staff && i.user.id !== rec.userId) return i.reply({ content: tr(lang, 'ticket.staffOnly'), flags: EPHEMERAL });
    if (closing.has(i.channelId)) return i.deferUpdate().catch(() => {});
    closing.add(i.channelId);
    try {
      await i.reply(tr(lang, 'ticket.closing'));
      await sleep(5000);

      const channel = i.channel;
      let file = null;
      if (process.env.MESSAGE_CONTENT === 'true') {
        try {
          const text = await buildTranscript(channel);
          file = new AttachmentBuilder(Buffer.from(text || '-', 'utf8'), { name: `transcript-${channel.name}.txt` });
        } catch (e) {
          console.error('[tickets] transcript failed:', e.message);
        }
      }

      const logChannel = g.ticketLogChannel ? await i.guild.channels.fetch(g.ticketLogChannel).catch(() => null) : null;
      if (logChannel && logChannel.isTextBased()) {
        const embed = new EmbedBuilder()
          .setColor(COLOR)
          .setTitle(tr(lang, 'ticket.closedLog'))
          .addFields(
            { name: tr(lang, 'ticket.opener'), value: `<@${rec.userId}>`, inline: true },
            { name: tr(lang, 'ticket.closedBy'), value: `<@${i.user.id}>`, inline: true },
            { name: tr(lang, 'ticket.category'), value: String(rec.catLabel || '-').slice(0, 1024), inline: true }
          )
          .setFooter({ text: '#' + channel.name })
          .setTimestamp();
        await logChannel.send({ embeds: [embed], files: file ? [file] : [], allowedMentions: { parse: [] } }).catch((e) => console.error('[tickets] log failed:', e.message));
      }

      delete g.tickets[channel.id];
      store.save();
      await channel.delete('Ticket closed by ' + i.user.tag);
    } catch (e) {
      console.error('[tickets] close failed:', e.message);
    } finally {
      closing.delete(i.channelId);
    }
  }
  return undefined;
}

module.exports = { sendPanel, onSelect, onModal, onButton, EMOJI_RE };