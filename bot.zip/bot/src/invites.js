'use strict';

const { PermissionFlagsBits } = require('discord.js');

// guildId -> { invites: Map(code -> { uses, maxUses, inviterId }), vanity: number | null }
const cache = new Map();

function snapshot(invites) {
  const m = new Map();
  for (const i of invites.values()) {
    m.set(i.code, { uses: i.uses ?? 0, maxUses: i.maxUses ?? 0, inviterId: i.inviter?.id ?? null });
  }
  return m;
}

async function vanityUses(guild) {
  if (!guild.vanityURLCode) return null;
  try {
    const v = await guild.fetchVanityData();
    return typeof v.uses === 'number' ? v.uses : null;
  } catch {
    return null;
  }
}

// Take a snapshot of the guild invites. Needs the Manage Server permission.
async function prime(guild) {
  try {
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
      cache.delete(guild.id);
      return false;
    }
    const invites = await guild.invites.fetch();
    cache.set(guild.id, { invites: snapshot(invites), vanity: await vanityUses(guild) });
    return true;
  } catch (e) {
    cache.delete(guild.id);
    console.error('[invites] prime failed for', guild.id, e.message);
    return false;
  }
}

function onCreate(invite) {
  const entry = cache.get(invite.guild?.id);
  if (!entry) return;
  entry.invites.set(invite.code, { uses: invite.uses ?? 0, maxUses: invite.maxUses ?? 0, inviterId: invite.inviter?.id ?? null });
}

// Work out which invite a new member used by comparing use counters with the last snapshot.
// Returns { type: 'invite' | 'vanity' | 'bot' | 'unknown', code?, uses?, inviterId? }.
// Two members joining at the exact same moment can be attributed to the wrong invite.
async function detect(member) {
  if (member.user.bot) return { type: 'bot' };
  const guild = member.guild;
  const before = cache.get(guild.id);
  if (!before) return { type: 'unknown' };

  let after;
  try {
    after = snapshot(await guild.invites.fetch());
  } catch {
    return { type: 'unknown' };
  }
  const vanityNow = await vanityUses(guild);

  let result = { type: 'unknown' };

  for (const [code, cur] of after) {
    const prev = before.invites.get(code);
    if (cur.uses > (prev ? prev.uses : 0)) {
      result = { type: 'invite', code, uses: cur.uses, inviterId: cur.inviterId };
      break;
    }
  }

  if (result.type === 'unknown') {
    // Single-use or max-use invites disappear as soon as they are consumed.
    for (const [code, prev] of before.invites) {
      if (!after.has(code) && prev.maxUses > 0 && prev.uses + 1 >= prev.maxUses) {
        result = { type: 'invite', code, uses: prev.uses + 1, inviterId: prev.inviterId };
        break;
      }
    }
  }

  if (result.type === 'unknown' && before.vanity !== null && vanityNow !== null && vanityNow > before.vanity) {
    result = { type: 'vanity', code: guild.vanityURLCode };
  }

  cache.set(guild.id, { invites: after, vanity: vanityNow });
  return result;
}

module.exports = { prime, onCreate, detect };