#!/usr/bin/env bash
# Installs / updates the bot on the VPS. Expects the archive at /tmp/ucbot.tgz.
# Never overwrites an existing .env or the data directory.
set -euo pipefail

APP=/opt/unlimited-claud-bot
SVC=ucbot
NODE_BIN="$(command -v node)"

id -u "$SVC" >/dev/null 2>&1 || useradd --system --home-dir "$APP" --shell /usr/sbin/nologin "$SVC"
mkdir -p "$APP/data"
tar -xzf /tmp/ucbot.tgz -C "$APP"
rm -f /tmp/ucbot.tgz
cd "$APP"

npm ci --omit=dev --no-audit --no-fund

if [ ! -f .env ]; then
  cp .env.example .env
  SECRET="$(openssl rand -hex 32)"
  sed -i "s/^API_SECRET=.*/API_SECRET=${SECRET}/" .env
  echo "Created .env with a generated API_SECRET."
fi

chown -R "$SVC:$SVC" "$APP"
chmod 600 "$APP/.env"

cat > /etc/systemd/system/${SVC}.service <<EOF
[Unit]
Description=Unlimited Claud Discord bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SVC}
WorkingDirectory=${APP}
ExecStart=${NODE_BIN} --env-file=${APP}/.env src/index.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${APP}/data

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SVC" >/dev/null 2>&1
echo "Installed. Fill DISCORD_TOKEN, DISCORD_CLIENT_ID and OWNER_IDS in ${APP}/.env then: systemctl restart ${SVC}"